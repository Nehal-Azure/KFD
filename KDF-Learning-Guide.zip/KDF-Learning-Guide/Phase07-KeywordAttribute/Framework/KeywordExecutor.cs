// ══════════════════════════════════════════════════════════════════
// FILE: Framework/KeywordAttribute.cs
// ══════════════════════════════════════════════════════════════════

namespace Phase07;

using System.Reflection;

/// <summary>
/// Marks a public instance method of KeywordExecutor as the implementation
/// of a named keyword. The Name is what appears in the CSV Action_Type column.
///
/// Using an attribute (instead of a dictionary entry) means:
///   • Adding a keyword = adding one method. Nothing else to update.
///   • Typos in the key are caught by InvokeKeyword at runtime (clear message).
///   • The HTML documentation generator can discover all keywords automatically.
///
/// Required method signature:
///   public async Task MethodName(KeywordStep step)
/// </summary>
[AttributeUsage(AttributeTargets.Method)]
public class KeywordAttribute : Attribute
{
    /// <summary>The keyword key string: "Action_Type", e.g. "Enter_TextBox".</summary>
    public string Name { get; }

    /// <summary>Human description — appears in the HTML keyword reference page.</summary>
    public string Description { get; }

    public KeywordAttribute(string name, string description = "")
    {
        Name        = name;
        Description = description;
    }
}

// ══════════════════════════════════════════════════════════════════
// FILE: Framework/KeywordExecutor.cs
// ══════════════════════════════════════════════════════════════════

/// <summary>
/// The central engine of the keyword-driven framework.
///
/// Each public method marked [Keyword("Action_Type")] is one keyword
/// implementation. InvokeKeyword discovers and calls the right method
/// via reflection — no manual dictionary to maintain.
///
/// Adding a new keyword: write one method with the [Keyword] attribute.
/// Removing a keyword: delete the method. That's it.
/// </summary>
public class KeywordExecutor
{
    // ── State ────────────────────────────────────────────────────────────
    private IPage    _currentPage;   // the active browser tab
    private object?  _currentPom;    // the active page object (for locator resolution)
    private readonly string _testName;  // used to name screenshots

    public KeywordExecutor(IPage page, string testName)
    {
        _currentPage = page;
        _testName    = testName;
    }

    // ── Public entry point ───────────────────────────────────────────────

    /// <summary>
    /// Builds the keyword key from the step's Action and Type, then
    /// dispatches to the matching [Keyword] method via reflection.
    /// </summary>
    public async Task Execute(KeywordStep step)
    {
        var key = $"{step.Action}_{step.Type}";
        await InvokeKeyword(key, step);
    }

    // ── Reflection dispatcher ────────────────────────────────────────────

    private async Task InvokeKeyword(string key, KeywordStep step)
    {
        // Scan every public instance method on this class for one
        // whose [KeywordAttribute].Name matches the key (case-insensitive).
        var method = GetType()
            .GetMethods(BindingFlags.Public | BindingFlags.Instance)
            .FirstOrDefault(m =>
            {
                var attr = m.GetCustomAttribute<KeywordAttribute>();
                return attr != null &&
                       attr.Name.Equals(key, StringComparison.OrdinalIgnoreCase);
            });

        if (method == null)
        {
            // Build a helpful list of all registered keywords for the error message.
            var available = GetType()
                .GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .Select(m => m.GetCustomAttribute<KeywordAttribute>()?.Name)
                .Where(n => n != null)
                .OrderBy(n => n);

            throw new Exception(
                $"Keyword not implemented: '{key}'\n" +
                $"Available keywords: {string.Join(", ", available)}");
        }

        // Invoke the method. All keyword methods return Task, so cast and await.
        var result = method.Invoke(this, new object[] { step });
        if (result is Task task)
            await task;
    }

    // ══════════════════════════════════════════════════════════════════════
    // KEYWORD METHODS
    // Each method below is one keyword. The C# method name is irrelevant for
    // dispatch — only [Keyword].Name matters. Use descriptive C# names.
    // ══════════════════════════════════════════════════════════════════════

    [Keyword("NavigateTo_URL",
        "Navigates the browser to the URL given in the Item column.")]
    public async Task NavigateToUrl(KeywordStep step)
    {
        Console.WriteLine($"  🌐 Navigate → {step.Item}");
        await _currentPage.GotoAsync(step.Item);
        await _currentPage.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
        _currentPom = DetectCurrentPage(_currentPage.Url);
        Console.WriteLine($"  ✅ Active POM: {_currentPom?.GetType().Name ?? "none"}");
    }

    [Keyword("Enter_TextBox",
        "Types the text in Value into the field identified by Item.")]
    public async Task EnterTextBox(KeywordStep step)
    {
        if (string.IsNullOrWhiteSpace(step.Item))
            throw new ArgumentException("Enter_TextBox requires an Item (field name).");
        if (string.IsNullOrWhiteSpace(step.Value))
            throw new ArgumentException($"Enter_TextBox requires a Value (text to type). Item='{step.Item}'.");

        Console.WriteLine($"  ⌨️  Fill '{step.Item}' with '{step.Value}'");
        var element = GetLocator(step.Item);
        await element.FillAsync(step.Value);
    }

    [Keyword("Click_Button",
        "Clicks the button or link identified by Item. Detects post-click navigation.")]
    public async Task ClickButton(KeywordStep step)
    {
        Console.WriteLine($"  🖱️  Click '{step.Item}'");
        var element  = GetLocator(step.Item);
        var urlBefore = _currentPage.Url;

        await element.ClickAsync();
        await _currentPage.WaitForLoadStateAsync(LoadState.DOMContentLoaded);

        if (_currentPage.Url != urlBefore)
        {
            _currentPom = DetectCurrentPage(_currentPage.Url);
            Console.WriteLine($"  🔀 Navigated → POM: {_currentPom?.GetType().Name}");
        }
    }

    [Keyword("Verify_Visible",
        "Asserts the element named by Item is visible on the page. Auto-retries.")]
    public async Task VerifyVisible(KeywordStep step)
    {
        Console.WriteLine($"  👁️  Verify visible: '{step.Item}'");
        var element = GetLocator(step.Item);
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(element).ToBeVisibleAsync(),
            step);
        Console.WriteLine($"  ✅ Visible confirmed");
    }

    [Keyword("Verify_Text",
        "Asserts the element named by Item contains the text in Value. Auto-retries.")]
    public async Task VerifyText(KeywordStep step)
    {
        Console.WriteLine($"  📝 Verify text '{step.Item}' contains '{step.Value}'");
        var element = GetLocator(step.Item);
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(element).ToContainTextAsync(step.Value),
            step);
        Console.WriteLine($"  ✅ Text confirmed");
    }

    [Keyword("Verify_Enabled",
        "Asserts the element named by Item is not disabled. Auto-retries.")]
    public async Task VerifyEnabled(KeywordStep step)
    {
        Console.WriteLine($"  ⚡ Verify enabled: '{step.Item}'");
        var element = GetLocator(step.Item);
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(element).ToBeEnabledAsync(),
            step);
        Console.WriteLine($"  ✅ Enabled confirmed");
    }

    [Keyword("Capture_Screenshot",
        "Saves a full-page screenshot. Item is used as the filename (without extension).")]
    public async Task CaptureScreenshot(KeywordStep step)
    {
        var name   = string.IsNullOrWhiteSpace(step.Item) ? "screenshot" : step.Item;
        var folder = Path.Combine("Screenshots", _testName.Replace(" ", "_"));
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"{name}.png");
        await _currentPage.ScreenshotAsync(new() { Path = path, FullPage = true });
        Console.WriteLine($"  📸 Screenshot → {path}");
    }

    [Keyword("Pause_Seconds",
        "Pauses execution for the number of seconds given in Value.")]
    public async Task PauseSeconds(KeywordStep step)
    {
        if (!int.TryParse(step.Value, out var seconds))
            throw new ArgumentException($"Pause_Seconds requires an integer in Value. Got: '{step.Value}'");

        Console.WriteLine($"  ⏸  Pause {seconds}s");
        await Task.Delay(seconds * 1000);
    }

    // ══════════════════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Resolves a logical name → ILocator using the page object model.
    /// Throws a clear exception if the name is not found anywhere.
    /// </summary>
    private ILocator GetLocator(string name)
    {
        var locator = SimpleLocatorResolver.Resolve(name, _currentPage, _currentPom);
        return locator
            ?? throw new Exception(
                $"Locator '{name}' not found in any registered page object.\n" +
                "Add a property with [Locator(\"" + name + "\", ...)] to the right page class.");
    }

    /// <summary>
    /// Runs an assertion. If it throws, captures a screenshot before re-throwing.
    /// The screenshot is evidence; the re-throw ensures the test still fails.
    /// </summary>
    private async Task ExecuteAssertWithScreenshot(Func<Task> assertAction, KeywordStep step)
    {
        try
        {
            await assertAction();
        }
        catch
        {
            await CaptureFailureScreenshot($"{step.Action}_{step.Type}_{step.Item}");
            throw;   // bare throw: preserves original exception and stack trace
        }
    }

    /// <summary>
    /// Saves a full-page screenshot to Screenshots/Failures/.
    /// Any errors here are swallowed — a screenshot failure must never
    /// hide the original assertion failure.
    /// </summary>
    private async Task CaptureFailureScreenshot(string name)
    {
        try
        {
            var folder    = Path.Combine("Screenshots", "Failures", _testName.Replace(" ", "_"));
            Directory.CreateDirectory(folder);
            var timestamp = DateTime.Now.ToString("HHmmss_fff");
            var path      = Path.Combine(folder, $"FAIL_{name}_{timestamp}.png");
            await _currentPage.ScreenshotAsync(new() { Path = path, FullPage = true });
            Console.WriteLine($"  📸 FAILURE screenshot → {Path.GetFullPath(path)}");
        }
        catch (Exception e)
        {
            Console.WriteLine($"  ⚠️  Screenshot failed: {e.Message}");
        }
    }

    /// <summary>
    /// Returns the correct page object for the current URL.
    /// In PRISM, NavigationTracker does this via browser context events.
    /// </summary>
    private object? DetectCurrentPage(string url) =>
        url switch
        {
            var u when u.Contains("/inventory") => new ProductsPage(_currentPage),
            _                                   => new LoginPage(_currentPage)
        };
}
