// Phase 06 — Assertions and Screenshot on Failure
//
// Run with: dotnet run
//
// What's new vs Phase 05:
//   - Assertions.Expect() used instead of IsVisibleAsync() — auto-retries until timeout
//   - Verify_Text keyword added
//   - ExecuteAssertWithScreenshot wraps every assertion
//   - CaptureFailureScreenshot saves evidence when an assertion fails
//   - The CSV contains a DELIBERATE FAILURE on step 09 to show the pattern working

using Microsoft.Playwright;
using Phase06;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 06 — Assertions + Screenshot on Failure    ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── Playwright lifecycle ────────────────────────────────────────────
using var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new() { Headless = false, SlowMo = 300 });
var context = await browser.NewContextAsync();
var page    = await context.NewPageAsync();
page.SetDefaultTimeout(10_000);   // 10 seconds for assertions (not 30) — faster feedback in dev

object? currentPom = null;

// ── Keyword dictionary ───────────────────────────────────────────────
var keywords = new Dictionary<string, Func<KeywordStep, Task>>(StringComparer.OrdinalIgnoreCase)
{
    ["NavigateTo_URL"] = async step =>
    {
        Console.WriteLine($"  🌐 Navigate → {step.Item}");
        await page.GotoAsync(step.Item);
        currentPom = DetectCurrentPage(page.Url);
    },

    ["Enter_TextBox"] = async step =>
    {
        var e = GetLocator(step.Item) ?? throw new Exception($"Locator '{step.Item}' not found.");
        Console.WriteLine($"  ⌨️  Fill '{step.Item}'");
        await e.FillAsync(step.Value);
    },

    ["Click_Button"] = async step =>
    {
        var e = GetLocator(step.Item) ?? throw new Exception($"Locator '{step.Item}' not found.");
        Console.WriteLine($"  🖱️  Click '{step.Item}'");
        var urlBefore = page.Url;
        await e.ClickAsync();
        await page.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
        if (page.Url != urlBefore)
        {
            currentPom = DetectCurrentPage(page.Url);
            Console.WriteLine($"  🔀 Navigated → POM: {currentPom?.GetType().Name}");
        }
    },

    // ── Verify_Visible — uses Playwright's auto-retrying Expect ─────────
    ["Verify_Visible"] = async step =>
    {
        Console.WriteLine($"  👁️  Verify visible: '{step.Item}'");
        var e = GetLocator(step.Item) ?? throw new Exception($"Locator '{step.Item}' not found.");

        // ExecuteAssertWithScreenshot runs the assertion inside a try/catch.
        // If it throws (element never became visible), a screenshot is saved first.
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(e).ToBeVisibleAsync(),
            $"Verify_Visible_{step.Item}");

        Console.WriteLine($"  ✅ '{step.Item}' is visible");
    },

    // ── Verify_Text — the element's text must contain step.Value ────────
    ["Verify_Text"] = async step =>
    {
        Console.WriteLine($"  📝 Verify text of '{step.Item}' contains '{step.Value}'");
        var e = GetLocator(step.Item) ?? throw new Exception($"Locator '{step.Item}' not found.");

        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(e).ToContainTextAsync(step.Value),
            $"Verify_Text_{step.Item}");

        Console.WriteLine($"  ✅ Text check passed");
    },

    // ── Verify_Enabled — element must be interactive (not disabled) ──────
    ["Verify_Enabled"] = async step =>
    {
        Console.WriteLine($"  ⚡ Verify enabled: '{step.Item}'");
        var e = GetLocator(step.Item) ?? throw new Exception($"Locator '{step.Item}' not found.");

        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(e).ToBeEnabledAsync(),
            $"Verify_Enabled_{step.Item}");

        Console.WriteLine($"  ✅ '{step.Item}' is enabled");
    },

    ["Capture_Screenshot"] = async step =>
    {
        var folder = "Screenshots";
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"{step.Item}.png");
        await page.ScreenshotAsync(new() { Path = path, FullPage = true });
        Console.WriteLine($"  📸 Screenshot → {path}");
    }
};

// ── ExecuteAssertWithScreenshot ──────────────────────────────────────
// EVERY assertion keyword calls this instead of running Expect directly.
// Pattern: run assertion → if it throws → capture screenshot → re-throw.
// The screenshot is evidence; the re-throw ensures the test still fails.
async Task ExecuteAssertWithScreenshot(Func<Task> assertAction, string description)
{
    try
    {
        await assertAction();
    }
    catch   // assertion failed
    {
        await CaptureFailureScreenshot(description);
        throw;   // bare throw: re-throws the original exception unchanged
    }
}

// ── CaptureFailureScreenshot ─────────────────────────────────────────
async Task CaptureFailureScreenshot(string name)
{
    try
    {
        var folder = Path.Combine("Screenshots", "Failures");
        Directory.CreateDirectory(folder);

        // Milliseconds in timestamp prevents overwriting if two steps fail fast.
        var timestamp = DateTime.Now.ToString("HHmmss_fff");
        var path = Path.Combine(folder, $"FAIL_{name}_{timestamp}.png");

        await page.ScreenshotAsync(new PageScreenshotOptions { Path = path, FullPage = true });
        Console.WriteLine($"  📸 FAILURE screenshot: {Path.GetFullPath(path)}");
    }
    catch (Exception e)
    {
        // If the page itself crashed we cannot screenshot it.
        // Swallow the error — the original assertion failure is more important.
        Console.WriteLine($"  ⚠️  Could not screenshot: {e.Message}");
    }
}

// ── Helpers ─────────────────────────────────────────────────────────
ILocator? GetLocator(string name) =>
    SimpleLocatorResolver.Resolve(name, page, currentPom);

object? DetectCurrentPage(string url) =>
    url switch
    {
        var u when u.Contains("/inventory") => new ProductsPage(page),
        _                                   => new LoginPage(page)
    };

// ── Read and execute ─────────────────────────────────────────────────
var filePath = Path.Combine("TestData", "01_Login_With_Assertions.csv");
if (!File.Exists(filePath)) { Console.WriteLine($"❌ Not found: {filePath}"); return; }

var steps  = CsvStepReader.ReadSteps(filePath).OrderBy(s => s.TestStep).ToList();
Console.WriteLine($"📄 Loaded {steps.Count} steps\n═══ Running ═══\n");

var passed = true;
foreach (var step in steps)
{
    Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}");

    if (!keywords.TryGetValue(step.KeywordKey, out var impl))
    {
        Console.WriteLine($"  ❌ Unknown keyword: '{step.KeywordKey}'");
        passed = false; break;
    }
    try { await impl(step); }
    catch (Exception ex)
    {
        Console.WriteLine($"  ❌ STEP FAILED: {ex.Message.Split('\n')[0]}");
        await CaptureFailureScreenshot($"Step{step.TestStep}_{step.KeywordKey}");
        passed = false; break;
    }
    Console.WriteLine();
}

await context.CloseAsync();
await browser.CloseAsync();

Console.WriteLine(passed ? "\n✅ ALL STEPS COMPLETED" : "\n❌ TEST FAILED — check Screenshots/Failures/");
Console.WriteLine("See GUIDE.md for practice exercises before moving to Phase 07.");
