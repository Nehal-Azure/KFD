# Keyword-Driven Framework — Learning Guide
### From Zero to Contributor in 10 Phases

---

## Who is this guide for?

You have experience building **data-driven test frameworks with Page Object
Model** — you know what a `WebDriver`, a `LoginPage` class, and an Excel/CSV
data reader look like. What you have not built before is a **keyword-driven
framework**. This guide bridges that exact gap.

By the end of Phase 10 you will understand every component of the team's
PRISM keyword-driven framework, know why each design decision was made, and
be able to add new pages and keywords confidently without breaking anything.

---

## How to use this guide

Each phase lives in its own folder. Work through them in order:

1. **Read the `GUIDE.md`** inside the phase folder — it explains the new
   concept being introduced, why it exists, and how it fits into the bigger
   picture.
2. **Type out the code** (don't copy-paste — the typing is part of learning).
3. **Run it** to confirm it works.
4. **Complete the Practice Exercises** at the bottom of each `GUIDE.md`
   before moving to the next phase. These build your confidence with the
   concept before you face a more complex version of it.

Phases 1–2 are pure C# console apps — no NuGet packages, no browser. They
exist purely to teach you the core data-reading and dispatch mechanisms
without any testing-framework noise getting in the way.

Phases 3–8 add Playwright, page objects, the keyword attribute, and variables.

Phases 9–10 wire everything into NUnit and add Allure reporting — this is
where the code converges with the team's actual PRISM framework structure.

---

## The target application

All browser-based phases use **SauceDemo** (`https://www.saucedemo.com`) — a
free, publicly available demo e-commerce site built specifically for
automation practice. No account creation is needed, and it never goes down.

Credentials:
- Username: `standard_user`
- Password: `secret_sauce`

---

## The mental model you need first

Before writing a line of code, read this. It is the entire concept of a
keyword-driven framework in three bullet points:

- **A data-driven framework** says: "These are the test steps (hard-coded in
  C#). Here is some data to feed through them."
- **A keyword-driven framework** says: "Here is a table of rows. Each row
  names an action. The framework looks up that action and runs it." The
  *steps* move into the data file. The C# only describes what each named
  action means.
- The CSV file you will build in Phase 1 is the **test case**. The
  `KeywordExecutor` you will build in Phase 7 is the **interpreter** that
  reads it.

```
CSV row:   Click,Button,LoginButton,,
           ^     ^      ^
           |     |      +-- "Item" = logical name of the thing to act on
           |     +--------- "Type" = what kind of thing it is
           +--------------- "Action" = what to do

Combined key: "Click_Button"
Framework looks up "Click_Button" → finds the method → runs it against "LoginButton"
```

---

## Phase overview

| Phase | Concept introduced | New framework component |
|---|---|---|
| 01 | Reading a CSV into objects | `CsvStepReader` |
| 02 | Dispatching by keyword name | Basic `Dictionary<string, Action>` |
| 03 | Real browser with Playwright | `NavigateTo_URL`, `Capture_Screenshot` |
| 04 | Page Object + `[Locator]` attribute | `LoginPage`, `LocatorAttribute`, `SimpleLocatorResolver` |
| 05 | Full login test end-to-end | `Enter_TextBox`, `Click_Button` |
| 06 | Assertions + screenshot on failure | `Verify_Visible`, `Verify_Text`, `ExecuteAssertWithScreenshot` |
| 07 | `[Keyword]` attribute + reflection | `KeywordAttribute`, reflection-based `InvokeKeyword` |
| 08 | Test variables | `VariableManager`, `Capture_Value`, `${token}` syntax |
| 09 | NUnit wiring: TestBase + TestCaseSource | `TestBase`, `KeywordTests`, folder-per-test discovery |
| 10 | Allure reporting + artifacts | `AllureNUnit`, step wrapping, trace, video, screenshot |

---

## Connecting back to the PRISM framework

After Phase 10, open the colleague's framework and you will find:

| Your phase | Colleague's file |
|---|---|
| Phase 01 — `CsvStepReader` | `Framework/Data/CsvStepReader.cs` |
| Phase 02 — dispatcher dict | Superseded by Phase 07 |
| Phase 03 — browser keywords | `Framework/Engine/KeywordExecutor.cs` (NavigateTo_URL etc.) |
| Phase 04 — `[Locator]` + resolver | `Framework/Locators/LocatorAttribute.cs`, `SimpleLocatorResolver.cs` |
| Phase 05/06 — login + asserts | `Pages/LoginPage.cs`, verify keywords in `KeywordExecutor.cs` |
| Phase 07 — `[Keyword]` + reflection | `Framework/Engine/KeywordAttribute.cs`, `InvokeKeyword()` |
| Phase 08 — variables | `VariableManager.cs`, `Capture_Value`, `ResolveVariable()` |
| Phase 09 — NUnit | `TestBase.cs`, `Tests/KeywordTests.cs` |
| Phase 10 — Allure | Updated `TestBase.cs` + `KeywordTests.cs` from the Allure review |

---

## Prerequisites

Install these once before starting Phase 1:
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- Any text editor or IDE (VS Code with C# extension, Visual Studio, or Rider)

Playwright browsers are installed automatically when Phase 3 first runs.

---

## Quick-start: creating a new phase project

Every phase except 01 and 02 uses this same command:

```bash
cd Phase0X-Name
dotnet new nunit     # phases 9 and 10 only
dotnet new console   # phases 1–8
dotnet restore
dotnet run           # phases 1–8
dotnet test          # phases 9–10
```

Each phase folder contains the complete `.csproj` file pre-configured with
the right packages, so `dotnet restore` is all you need after copying the
`.csproj` into a new project folder.
