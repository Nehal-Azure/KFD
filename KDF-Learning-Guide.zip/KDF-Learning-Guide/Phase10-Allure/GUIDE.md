# Phase 10 — Allure Reporting + Playwright Artifacts

## What you will build

The complete reporting layer: every test case becomes a clickable Allure
report entry with individual step breakdowns, automatic screenshots on
failure, Playwright trace files (openable at trace.playwright.dev), and
recorded video — all attached directly inside the Allure report without
anyone navigating a file system.

This is the final phase. After completing it, the framework you have built
is structurally and functionally equivalent to the team's PRISM framework.

## What Allure gives you

Without Allure, `dotnet test` produces console output and a `.trx` XML file.
A team member not at a terminal sees nothing useful. With Allure:

- **Every test** is a clickable page in a web report.
- **Every step** inside a test (each CSV row) is a labelled, colour-coded
  entry — pass steps are green, the failed step is red with its message.
- **Screenshots, traces, and videos** are attached inline — a QA manager can
  see what happened without opening a file explorer.
- **History and trends** persist across runs so you can see if a test is
  newly failing or has been flaky for weeks.

## The three additions to `TestBase.cs`

### 1. `[AllureNUnit]` on the class

```csharp
[AllureNUnit]
public class TestBase { ... }
```

This single attribute activates the Allure integration for this class and
every class that inherits from it (`KeywordTests` inherits `TestBase`, so
it gets Allure for free with no extra attribute).

**This is the attribute that was mentioned in comments but never actually
added to the code in the PRISM framework.** Without it, no `allure-results/`
files are written and nothing appears in the report.

### 2. Video and tracing in `[SetUp]`

```csharp
// Video: context created with a RecordVideoDir
Context = await Browser.NewContextAsync(new BrowserNewContextOptions
{
    ViewportSize    = null,
    RecordVideoDir  = _videoDir,         // ← where .webm files land
    RecordVideoSize = new() { Width = 1280, Height = 720 }
});

// Tracing: started after the context + page exist
await Context.Tracing.StartAsync(new TracingStartOptions
{
    Title       = TestContext.CurrentContext.Test.Name,
    Screenshots = true,
    Snapshots   = true,
    Sources     = true
});
```

### 3. Screenshot, trace, video attachment in `[TearDown]`

```csharp
// a. Screenshot on failure
if (failed) { ... AllureApi.AddAttachment(name, "image/png", bytes); }

// b. Stop trace (flush always; save only when TraceMode demands it)
await Context.Tracing.StopAsync(new TracingStopOptions { Path = tracePath });
AllureApi.AddAttachment(name, "application/zip", tracePath);

// c. Close context FIRST — this finalises the .webm file
await Context.CloseAsync();

// d. Attach video
AllureApi.AddAttachment(name, "video/webm", videoFilePath);
```

**Why close the context before reading the video?** Playwright writes the
final `.webm` file on context close, not on every frame. If you try to read
the video file before closing the context you get an empty or partial file.
This ordering — stop trace → close context → attach video — is the critical
sequence that ensures all three artifacts exist before Allure tries to attach
them.

## The addition to `KeywordTests.cs`

Wrap each step in `AllureApi.Step(...)`:

```csharp
await AllureApi.Step(stepLabel, async () =>
{
    try
    {
        await executor.Execute(step);
    }
    catch (Exception ex)
    {
        // Attach step-level screenshot to THIS SPECIFIC STEP in Allure
        var bytes = await Page.ScreenshotAsync(new() { FullPage = true });
        AllureApi.AddAttachment($"FAIL_Step{step.TestStep}.png", "image/png", bytes);
        throw;   // re-throw: marks this step FAILED in the report
    }
});
```

Without this, the whole test is one undifferentiated pass/fail. With it,
the Allure report shows exactly which of the 10 steps failed and what the
page looked like at that moment.

## NuGet package

Add to Phase10.csproj (the only new package vs Phase 09):

```xml
<PackageReference Include="Allure.NUnit" Version="2.12.1" />
```

This one package pulls in `Allure.Net.Commons` (the `AllureApi` class) and
the NUnit integration (`[AllureNUnit]`, `[AllureSuite]` attributes).

## Generating and viewing the report

```bash
# The allure-results/ folder is created automatically during the test run.
# Generate a static report:
allure generate allure-results -o allure-report --clean

# OR serve it locally with a one-command web server:
allure serve allure-results

# Install Allure CLI once if needed:
brew install allure               # macOS
npm install -g allure-commandline # Any OS with npm
```

## The `allureConfig.json`

Place this in the project root (copied to output dir via the `.csproj`):

```json
{
  "allure": {
    "directory": "allure-results",
    "links": [
      {
        "type": "issue",
        "urlTemplate": "https://jira.example.com/browse/{}",
        "nameTemplate": "Issue: {}"
      }
    ]
  }
}
```

This tells Allure where to write results and how to format issue links.

## TraceMode and CaptureAllVideos runsettings

```xml
<Parameter name="TraceMode"        value="OnFailure" />
<Parameter name="CaptureAllVideos" value="false"     />
```

- `TraceMode = "Off"` — never save traces
- `TraceMode = "OnFailure"` — save traces only for failing tests (default)
- `TraceMode = "Always"` — save traces for every test
- `CaptureAllVideos = false` — delete videos for passing tests (saves disk)
- `CaptureAllVideos = true` — keep all videos

## How this maps to the PRISM framework

After completing this phase, every file you have built maps exactly to a file
in the team's PRISM framework:

| Phase 10 | PRISM updated file (from the Allure integration review) |
|---|---|
| `TestBase.cs` | `TestBase.cs` (with `[AllureNUnit]`, tracing, video) |
| `Tests/KeywordTests.cs` | `Tests/KeywordTests.cs` (with `AllureApi.Step`) |
| `run-tests.sh` | `scripts/run-tests.sh` |
| `run-tests.bat` | `scripts/run-tests.bat` |
| `allureConfig.json` | `allureConfig.json` |

## What to do when `allure-results/` is empty after a run

This is almost always caused by `[AllureNUnit]` missing from `TestBase`.
Check the class declaration is exactly:

```csharp
[AllureNUnit]
public class TestBase { ... }
```

Not above the namespace, not on `KeywordTests`, on `TestBase` itself.

---

## Practice Exercises

**Exercise 1 — Confirm the attribute works**
After adding `[AllureNUnit]`, run one test and immediately check whether
`allure-results/` appears next to the built DLL. If the folder appears with
`.json` files inside it, the integration is working. If the folder is empty
or missing, `[AllureNUnit]` is not on `TestBase`.

**Exercise 2 — Force a failure and inspect the report**
Change `Verify_Text, ProductsTitle, Products` to
`Verify_Text, ProductsTitle, WRONG`. Run tests, then run `allure serve
allure-results`. Find the failed test, click it, and locate:
(a) The exact step that failed (red entry)
(b) The step-level screenshot embedded in that step's panel
(c) The test-level failure screenshot attached at the bottom
(d) The trace.zip attachment (download it, drag onto trace.playwright.dev)
(e) The video.webm attachment (play it inline or download)

**Exercise 3 — Add `[AllureSuite]` and `[AllureFeature]`**
Grouping in Allure is controlled by attributes:
```csharp
[AllureSuite("Authentication")]     // top-level group
[AllureFeature("CSV Keyword Tests")] // secondary group
public class KeywordTests : TestBase { ... }
```
After adding these, run `allure serve allure-results` and find your tests
under `Suites → Authentication → CSV Keyword Tests` in the report navigation.

**Exercise 4 — History tracking**
Run the full suite three times in a row (make sure `allure-results/` is NOT
cleared between runs — Allure accumulates history). On the third run, open
the report and look at the "History" tab for a test. You will see a
pass/fail trend across the three runs. This is the feature that makes Allure
genuinely useful in a CI environment — it shows whether a failure is new
or has been happening for days.
