# Phase 05 — Full Login Test End-to-End

## What you will build

A complete, working login-to-products test with:
- `LoginPage` driving the login form
- `ProductsPage` verifying the result
- The `_currentPom` variable switching automatically when navigation is detected
- The first hint of `NavigationTracker` (you will detect post-click URL change)

When you run this phase, Chromium opens, logs into SauceDemo, and confirms
the products page loaded — all driven purely from the CSV file.

## What's new in this phase

### 1. `ProductsPage` — a second page object

Until now you only had `LoginPage`. After clicking Login, you are on a
completely different screen. That screen gets its own page object:

```csharp
public class ProductsPage
{
    private readonly IPage _page;
    public ProductsPage(IPage page) { _page = page; }

    [Locator("ProductsTitle", "The 'Products' page heading", ".title")]
    public ILocator ProductsTitle => _page.Locator(".title");

    [Locator("InventoryList", "The product grid container", ".inventory_list")]
    public ILocator InventoryList => _page.Locator(".inventory_list");

    [Locator("MenuButton", "Hamburger menu opener", "#react-burger-menu-btn")]
    public ILocator MenuButton => _page.Locator("#react-burger-menu-btn");

    [Locator("LogoutLink", "Logout sidebar link", "#logout_sidebar_link")]
    public ILocator LogoutLink => _page.Locator("#logout_sidebar_link");
}
```

Add `typeof(ProductsPage)` to the `_pageTypes` array in `SimpleLocatorResolver`.

### 2. Switching the current POM after navigation

When `Click_Button` triggers a navigation (e.g. clicking LoginButton takes
you to the Products page), `_currentPom` must switch from `LoginPage` to
`ProductsPage`. Otherwise the resolver searches `LoginPage` first — which
doesn't know anything about `ProductsTitle` — and wastes time.

For now, a simple URL check after the click is enough:

```csharp
["Click_Button"] = async step =>
{
    var element = GetLocator(step.Item)
        ?? throw new Exception($"Locator '{step.Item}' not found.");

    Console.WriteLine($"  🖱️  Click '{step.Item}'");

    var urlBefore = page.Url;
    await element.ClickAsync();

    // Give the browser a moment to navigate, then check if URL changed.
    await page.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
    var urlAfter = page.Url;

    if (urlAfter != urlBefore)
    {
        Console.WriteLine($"  🔀 Navigation detected: {urlBefore} → {urlAfter}");
        // Switch to the page object that matches the new URL.
        currentPom = DetectCurrentPage(urlAfter, page);
        Console.WriteLine($"  📋 Active POM switched to: {currentPom?.GetType().Name}");
    }
}
```

`DetectCurrentPage` is a simple switch on the URL:

```csharp
object? DetectCurrentPage(string url, IPage page)
{
    if (url.Contains("/inventory"))  return new ProductsPage(page);
    if (url.Contains("/cart"))       return new CartPage(page);  // future phase
    return null;   // unknown screen — fall back to scanning all page types
}
```

This is a simplified version of what the PRISM `NavigationTracker` does. The
PRISM version detects new tabs, closed tabs, and same-tab navigation by
listening to browser context events — much more robust, but the concept is
the same: after any click, "which page are we on now?"

### 3. The `Verify_Visible` keyword (basic version)

```csharp
["Verify_Visible"] = async step =>
{
    var element = GetLocator(step.Item)
        ?? throw new Exception($"Locator '{step.Item}' not found.");

    Console.WriteLine($"  👁️  Verify '{step.Item}' is visible");

    // IsVisibleAsync checks right now — no retry, no wait.
    // Phase 06 introduces Playwright's auto-retrying assertion.
    var visible = await element.IsVisibleAsync();

    if (!visible)
        throw new Exception($"ASSERTION FAILED: '{step.Item}' is NOT visible on the page.");

    Console.WriteLine($"  ✅ '{step.Item}' is visible");
}
```

You will upgrade this to Playwright's auto-retrying `Expect` assertion in
Phase 06. For now, a direct `IsVisibleAsync` check is enough to prove the
concept works.

### 4. The complete test CSV

```
TestStep,Action,Type,Item,Value,Comments
01,NavigateTo,URL,https://www.saucedemo.com,,Open SauceDemo
02,Verify,Visible,Username,,Login form should be ready
03,Enter,TextBox,Username,standard_user,Type username
04,Enter,TextBox,Password,secret_sauce,Type password
05,Click,Button,LoginButton,,Submit — navigation to products happens here
06,Verify,Visible,ProductsTitle,,Products heading proves we landed correctly
07,Verify,Visible,InventoryList,,Product grid should be present
08,Capture,Screenshot,ProductsPage,,Capture the final state
```

Steps 06 and 07 are resolved against `ProductsPage` because `_currentPom`
switched to `ProductsPage` on step 05.

## Understanding the full data flow at this point

```
CSV row: "06,Verify,Visible,ProductsTitle,,"
                              ↓
                    step.Item = "ProductsTitle"
                              ↓
              GetLocator("ProductsTitle")
                              ↓
       SimpleLocatorResolver.Resolve("ProductsTitle", page, currentPom)
                              ↓
        currentPom is ProductsPage → GetFromInstance searches its properties
                              ↓
         Finds [Locator("ProductsTitle",...)] on ProductsPage.ProductsTitle
                              ↓
              returns ProductsPage.ProductsTitle = page.Locator(".title")
                              ↓
               await element.IsVisibleAsync() → true → pass
```

Every Phase before this was building toward this complete chain.

## How this maps to the PRISM framework

| Phase 05 concept | PRISM equivalent |
|---|---|
| `_currentPom` variable | `_currentPOM` field in `KeywordExecutor` |
| `DetectCurrentPage(url)` | `NavigationTracker.TrackAsync()` result's `.ToPage` |
| `Verify_Visible` with `IsVisibleAsync` | `Verify_Visible` in `KeywordExecutor` using `Assert.That(await locator.IsVisibleAsync(), Is.True)` |
| `ProductsPage` with `[Locator]` properties | `Pages/WorkPage.cs` in the PRISM framework |

---

## Practice Exercises

**Exercise 1 — Add logout steps**
Add three steps to the CSV after step 08:
- `09, Click, Button, MenuButton,` — opens the sidebar
- `10, Click, Button, LogoutLink,` — logs out (navigates back to login)
- `11, Verify, Visible, Username,` — confirms we are back on the login page

After step 10, `_currentPom` should switch back to `LoginPage` when
`DetectCurrentPage` sees the login URL. Implement this and confirm step 11
finds the `Username` locator on `LoginPage`.

**Exercise 2 — Wrong credentials**
Add a second CSV file `02_Failed_Login.csv` with the correct username but
the password `wrong_password`. Step 05 (`Click_Button LoginButton`) should
navigate — but back to the same login page with an error message.
Add a `Verify_Visible` step for `ErrorMessage` and confirm it passes.
What does `DetectCurrentPage` return for the login page URL?

**Exercise 3 — Add a CartPage**
SauceDemo has a cart page at `/cart.html`. Create a `CartPage` class with at
least two `[Locator]` properties (e.g. `CartTitle` and `CheckoutButton`).
Add a CSV step that clicks the cart icon (locator `ShoppingCartIcon` on
`ProductsPage`, selector `.shopping_cart_link`) and then verifies the cart
title is visible. You will need `DetectCurrentPage` to return `new CartPage(page)`
when the URL contains `"/cart"`.

**Exercise 4 — Understand why URL detection is fragile**
What happens if the application uses hash-based routing (`/#/inventory`)
instead of path-based routing (`/inventory.html`)? Would your
`DetectCurrentPage` still work? How would you make it more robust?
(This is exactly why the PRISM framework uses event-based navigation detection
via `NavigationTracker` rather than URL inspection.)
