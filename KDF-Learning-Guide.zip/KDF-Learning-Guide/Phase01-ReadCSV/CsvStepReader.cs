namespace Phase01;

/// <summary>
/// Reads a keyword-driven test CSV file and produces a sequence of
/// KeywordStep objects — one per data row.
///
/// DESIGN DECISION — why static?
/// This class has no state (no fields that change). It just reads a file
/// and returns data. Making it static means callers never have to write
/// "new CsvStepReader().ReadSteps(...)" — they just write
/// "CsvStepReader.ReadSteps(...)". The PRISM framework uses the same pattern.
///
/// DESIGN DECISION — why IEnumerable&lt;KeywordStep&gt;?
/// IEnumerable is the most general "sequence of items" type in C#.
/// Returning it allows the caller to further filter, sort, or paginate
/// without this class having to know about those needs. The caller (Program.cs
/// in Phase 01, KeywordTests.cs in Phase 09) adds .OrderBy(s => s.TestStep).
/// </summary>
public static class CsvStepReader
{
    /// <summary>
    /// Reads all data rows from a CSV file and maps each to a KeywordStep.
    /// </summary>
    /// <param name="filePath">
    /// Relative or absolute path to the CSV file.
    /// Relative paths are resolved from the working directory, which is
    /// the project folder when running via 'dotnet run'.
    /// </param>
    public static IEnumerable<KeywordStep> ReadSteps(string filePath)
    {
        // ReadAllLines reads the ENTIRE file into memory at once as a string[].
        // For test data files (typically < 1000 rows) this is fine.
        // A streaming reader (File.ReadLines) would be needed for truly huge files.
        var lines = File.ReadAllLines(filePath);

        return lines
            // Skip(1) discards the header row: "TestStep,Action,Type,Item,Value,Comments"
            // The header is for human readers — the engine only wants data rows.
            .Skip(1)

            // Filter out any blank lines (common at the end of Excel-saved CSVs).
            .Where(line => !string.IsNullOrWhiteSpace(line))

            // Transform each remaining line into a KeywordStep object.
            .Select(line =>
            {
                // Split on comma. StringSplitOptions.None preserves empty fields —
                // a row like "04,Click,Button,LoginButton,," has an empty Value column,
                // and we want that as "" not missing.
                var parts = line.Split(',', StringSplitOptions.None);

                return new KeywordStep
                {
                    // Direct positional mapping — column index to property.
                    // FRAGILE NOTE: if the CSV column order ever changes, these
                    // indices break silently. In Phase 09 you will see the PRISM
                    // framework keeps a strict column order convention to manage this.
                    TestStep = parts[0],
                    Action   = parts[1],
                    Type     = parts[2],
                    Item     = parts[3],

                    // Guard: Value (column 4) might not exist if the row has fewer
                    // than 5 columns. Rather than crashing, default to empty string.
                    Value    = parts.Length > 4 ? parts[4] : string.Empty,

                    // Guard: Comments (column 5) is fully optional.
                    Comments = parts.Length > 5 ? parts[5] : string.Empty
                };
            });
    }
}
