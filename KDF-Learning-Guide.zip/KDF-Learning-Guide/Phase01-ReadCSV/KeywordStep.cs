namespace Phase01;

/// <summary>
/// Represents one row in a keyword-driven test CSV file.
///
/// A keyword-driven test is just a table of rows. Each row says:
///   "Do this ACTION on this TYPE of thing called ITEM, with VALUE as input."
///
/// The framework reads this row, builds the keyword key (Action + "_" + Type),
/// looks it up in its registry, and calls the matching method.
///
/// You do not need the registry in Phase 01 — just understand the data shape.
/// </summary>
public class KeywordStep
{
    /// <summary>
    /// Zero-padded ordering number. Used to sort steps correctly.
    /// "01" sorts before "02" before "09" before "10".
    /// Plain int ordering would treat "10" as less than "9", which is wrong.
    /// </summary>
    public string TestStep { get; set; } = string.Empty;

    /// <summary>
    /// The VERB of the action. Examples: Enter, Click, Verify, Navigate, Capture.
    /// Always combined with Type to form the full keyword key.
    /// </summary>
    public string Action { get; set; } = string.Empty;

    /// <summary>
    /// The NOUN of the action — what kind of thing is being acted on.
    /// Examples: TextBox, Button, Visible, URL, Screenshot.
    /// Always combined with Action to form the full keyword key.
    /// The combined key "Action_Type" is what maps to a method in the framework.
    /// </summary>
    public string Type { get; set; } = string.Empty;

    /// <summary>
    /// The logical NAME of the element or the URL to navigate to.
    /// Examples: "Username", "LoginButton", "ProductsHeading",
    ///           "https://www.saucedemo.com"
    ///
    /// For element-targeting keywords, this name is looked up in the page
    /// object to find the actual Playwright selector. This separation means
    /// test authors write human-readable names, not CSS selectors.
    /// </summary>
    public string Item { get; set; } = string.Empty;

    /// <summary>
    /// Extra input data the action needs. Not all keywords need a value.
    /// Examples: "standard_user" (text to type), "true" (expected state),
    ///           empty for Click/Verify which don't need a value.
    /// </summary>
    public string Value { get; set; } = string.Empty;

    /// <summary>
    /// Human-readable note describing what this step does or expects.
    /// Never read by the engine — exists purely for the person reading the CSV.
    /// Optional: not all rows need a comment.
    /// </summary>
    public string Comments { get; set; } = string.Empty;

    /// <summary>
    /// Convenience property: builds the keyword key from Action and Type.
    /// This is the string the keyword registry uses to find the right method.
    /// Examples: "Enter_TextBox", "Click_Button", "Verify_Visible".
    /// </summary>
    public string KeywordKey => $"{Action}_{Type}";
}
