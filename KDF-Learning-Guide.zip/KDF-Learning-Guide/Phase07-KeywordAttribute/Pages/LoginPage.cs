// FILE: Pages/LoginPage.cs
// PURPOSE: Page Object for the SauceDemo login screen.
//
// Each property represents one interactive element on the page.
// The [Locator] attribute registers the property with SimpleLocatorResolver
// so the CSV can reference "Username" and the framework finds the right element.
//
// IMPORTANT — expression-bodied properties (=>) vs auto-properties ({ get; set; }):
// We use => because ILocator should be created fresh on every access.
// A Playwright locator is a QUERY DESCRIPTION, not a DOM node reference.
// Creating it fresh each time is correct, cheap, and avoids stale-element issues.

namespace Phase07;

using Microsoft.Playwright;

public class LoginPage
{
    private readonly IPage _page;

    // Constructor: IPage is injected so this class knows which browser tab to act on.
    // In Phase 09, TestBase creates the IPage and passes it in.
    public LoginPage(IPage page) { _page = page; }

    // ── Locators ────────────────────────────────────────────────────────────
    // Format: [Locator("LogicalName", "Description for docs", "Selector for docs")]
    // The logical name is what the CSV author types in the Item column.
    // The selector inside => _page.Locator("...") is what Playwright actually uses.

    [Locator("Username", "Username input field on login form", "#user-name")]
    public ILocator Username => _page.Locator("#user-name");

    [Locator("Password", "Password input field on login form", "#password")]
    public ILocator Password => _page.Locator("#password");

    [Locator("LoginButton", "The Login submit button", "#login-button")]
    public ILocator LoginButton => _page.Locator("#login-button");

    [Locator("ErrorMessage", "Error banner shown on a failed login attempt", "[data-test='error']")]
    public ILocator ErrorMessage => _page.Locator("[data-test='error']");
}
