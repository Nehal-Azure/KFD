// Phase 02 — The Keyword Dispatcher
//
// Run with: dotnet run
//
// What's new vs Phase 01:
//   - A Dictionary<string, Func<KeywordStep, Task>> maps keyword names to functions.
//   - An execution loop reads each step and calls the matching function.
//   - Unknown keywords stop the test immediately with a clear error.
//
// Still no browser. The functions just print what they WOULD do.
// That changes in Phase 03.

using Phase02;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 02 — The Keyword Dispatcher                ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── 1. Define the keyword dictionary ─────────────────────────────────────
//
// Key   = keyword key string (Action_Type)
// Value = an async function that accepts a KeywordStep and does the work
//
// In Phase 07 this dictionary will be replaced by automatic discovery
// via the [Keyword] attribute + reflection. For now, explicit registration
// is fine and teaches the concept clearly.

var keywords = new Dictionary<string, Func<KeywordStep, Task>>(
    StringComparer.OrdinalIgnoreCase)   // case-insensitive: "click_button" == "Click_Button"
{
    ["NavigateTo_URL"] = step =>
    {
        Console.WriteLine($"  🌐 NAVIGATE  → {step.Item}");
        return Task.CompletedTask;
    },

    ["Enter_TextBox"] = step =>
    {
        Console.WriteLine($"  ⌨️  ENTER     → Field: '{step.Item}'  Value: '{step.Value}'");
        return Task.CompletedTask;
    },

    ["Click_Button"] = step =>
    {
        Console.WriteLine($"  🖱️  CLICK     → Button: '{step.Item}'");
        return Task.CompletedTask;
    },

    ["Verify_Visible"] = step =>
    {
        Console.WriteLine($"  👁️  VERIFY    → '{step.Item}' is visible");
        return Task.CompletedTask;
    },

    ["Verify_Text"] = step =>
    {
        Console.WriteLine($"  📝 VERIFY    → '{step.Item}' contains text: '{step.Value}'");
        return Task.CompletedTask;
    },

    ["Capture_Screenshot"] = step =>
    {
        Console.WriteLine($"  📸 SCREENSHOT → Filename: '{step.Item}'");
        return Task.CompletedTask;
    }

    // Add new keywords here as you complete the exercises.
    // In Phase 07 this whole block goes away — keywords register themselves.
};

// ── 2. Read the test steps from CSV ──────────────────────────────────────
var filePath = Path.Combine("TestData", "01_Login_Test.csv");

if (!File.Exists(filePath))
{
    Console.WriteLine($"❌ Cannot find: {filePath}");
    return;
}

var steps = CsvStepReader.ReadSteps(filePath)
    .OrderBy(s => s.TestStep)
    .ToList();

Console.WriteLine($"📄 Loaded {steps.Count} steps from {filePath}");
Console.WriteLine();

// ── 3. Execute each step ──────────────────────────────────────────────────
Console.WriteLine("═══ Executing Test ═══");
Console.WriteLine();

var testPassed = true;

foreach (var step in steps)
{
    Console.Write($"[{step.TestStep}] {step.KeywordKey,-22} ");

    // Look up the keyword — this is the ENTIRE engine at this phase.
    if (!keywords.TryGetValue(step.KeywordKey, out var implementation))
    {
        Console.WriteLine();
        Console.WriteLine($"  ❌ UNKNOWN KEYWORD: '{step.KeywordKey}'");
        Console.WriteLine($"     Add it to the keywords dictionary in Program.cs");
        testPassed = false;
        break;   // stop immediately — an unknown keyword is an authoring error
    }

    // Call the function. In Phase 03 this will actually drive a browser.
    await implementation(step);
}

Console.WriteLine();
Console.WriteLine("═══ Result ═══");
Console.WriteLine(testPassed ? "✅ ALL STEPS COMPLETED" : "❌ TEST STOPPED ON UNKNOWN KEYWORD");
Console.WriteLine();
Console.WriteLine("See GUIDE.md for practice exercises before moving to Phase 03.");
