// ═══════════════════════════════════════════════════════════════════
// FILE: Pages/ProductsPage.cs
// PURPOSE: Page Object for the SauceDemo products (inventory) page.
//          Reached after a successful login.
// ═══════════════════════════════════════════════════════════════════

namespace Phase05;

using Microsoft.Playwright;

public class ProductsPage
{
    private readonly IPage _page;
    public ProductsPage(IPage page) { _page = page; }

    [Locator("ProductsTitle",   "The 'Products' heading at the top of the page", ".title")]
    public ILocator ProductsTitle   => _page.Locator(".title");

    [Locator("InventoryList",   "The product grid container holding all items", ".inventory_list")]
    public ILocator InventoryList   => _page.Locator(".inventory_list");

    [Locator("ShoppingCartIcon", "The cart icon in the top-right corner", ".shopping_cart_link")]
    public ILocator ShoppingCartIcon => _page.Locator(".shopping_cart_link");

    [Locator("MenuButton",      "The hamburger menu button (top-left)", "#react-burger-menu-btn")]
    public ILocator MenuButton      => _page.Locator("#react-burger-menu-btn");

    [Locator("LogoutLink",      "Logout link inside the open sidebar menu", "#logout_sidebar_link")]
    public ILocator LogoutLink      => _page.Locator("#logout_sidebar_link");
}
