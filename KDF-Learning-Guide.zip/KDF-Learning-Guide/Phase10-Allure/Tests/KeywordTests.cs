// Phase10-Allure/Tests/KeywordTests.cs
//
// Final version. Adds to Phase09 KeywordTests:
//   [AllureSuite]           — groups all tests under one Allure suite label
//   AllureApi.AddTestParameter — records test case name and step count in the report
//   AllureApi.Step(...)     — each CSV step becomes a labelled entry in the report
//   Step-level screenshot   — attached to the SPECIFIC STEP that failed

using Allure.Net.Commons;
using Allure.NUnit.Attributes;
using NUnit.Framework;

namespace Phase10;

[Parallelizable(ParallelScope.All)]
[FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
[TestFixture]
[AllureSuite("Keyword-Driven Tests")]       // Top-level grouping in the Allure report
public class KeywordTests : TestBase
{
    // ── Test case discovery ────────────────────────────────────────────────
    // Unchanged from Phase09: one subfolder in TestData/ = one test case.
    public static IEnumerable<TestCaseData> GetTestCases()
    {
        var root = Path.Combine(TestContext.CurrentContext.WorkDirectory, "TestData");

        if (!Directory.Exists(root))
            throw new DirectoryNotFoundException($"TestData not found at: {root}");

        return Directory.GetDirectories(root)
            .OrderBy(d => d)
            .Select(dir => new TestCaseData(Path.GetFileName(dir))
                .SetName(Path.GetFileName(dir)));
    }

    // ── Main test method ───────────────────────────────────────────────────
    [Test]
    [TestCaseSource(nameof(GetTestCases))]
    [AllureFeature("CSV Keyword Execution")]   // Secondary grouping in Allure
    public async Task RunCsvTests(string testCaseName)
    {
        Console.WriteLine($"🚀 {testCaseName} | Thread: {Environment.CurrentManagedThreadId}");

        // ── Allure metadata ────────────────────────────────────────────────
        // These appear in the "Parameters" table on the test's Allure page.
        AllureApi.AddTestParameter("TestCase", testCaseName);

        // ── Locate files ───────────────────────────────────────────────────
        var basePath      = Path.Combine("TestData", testCaseName);
        var stepsFile     = Directory.GetFiles(basePath, "*.csv")
                                .FirstOrDefault(f => !Path.GetFileName(f).Contains("Variables"));
        var variablesFile = Path.Combine(basePath, $"{testCaseName}_Variables.csv");

        if (stepsFile == null)
            throw new FileNotFoundException($"No steps CSV found in: {basePath}");

        // ── Load variables ─────────────────────────────────────────────────
        VariableManager.Load(variablesFile, TestContext.CurrentContext.Test.ID);

        // ── Read steps ─────────────────────────────────────────────────────
        var steps = CsvStepReader.ReadSteps(stepsFile)
            .OrderBy(s => s.TestStep)
            .ToList();

        // Record step count in the Allure parameters table.
        AllureApi.AddTestParameter("TotalSteps", steps.Count.ToString());

        Console.WriteLine($"📄 {steps.Count} steps from {Path.GetFileName(stepsFile)}");

        // ── Execute with Allure step wrapping ──────────────────────────────
        var executor = new KeywordExecutor(Page, testCaseName);

        foreach (var step in steps)
        {
            // Label shown as a collapsible step entry in the Allure report.
            var label = $"Step {step.TestStep}: {step.KeywordKey}" +
                        $"  [Item={step.Item}, Value={step.Value}]";

            Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}");

            // AllureApi.Step wraps this step's execution:
            //   • If it passes → green entry in the report.
            //   • If it throws → red entry with the exception message inline.
            await AllureApi.Step(label, async () =>
            {
                try
                {
                    await executor.Execute(step);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"  ❌ FAILED: {ex.Message.Split('\n')[0]}");

                    // Attach a screenshot specifically to THIS STEP in Allure.
                    // TestBase.TearDown will also attach a full-page screenshot
                    // to the test case level — both are useful:
                    //   Step-level: shows the exact state at the moment of failure.
                    //   Test-level: shows the full page after any cleanup/redirect.
                    try
                    {
                        var bytes = await Page.ScreenshotAsync(
                            new() { FullPage = true });

                        AllureApi.AddAttachment(
                            name:    $"FAIL_Step{step.TestStep}_{step.Item}.png",
                            type:    "image/png",
                            content: bytes);
                    }
                    catch { /* screenshot failure must not hide the real error */ }

                    throw;   // re-throw: marks STEP failed → marks TEST failed → TearDown runs
                }
            });
        }

        // ── Cleanup ────────────────────────────────────────────────────────
        VariableManager.Cleanup(TestContext.CurrentContext.Test.ID);
    }
}
