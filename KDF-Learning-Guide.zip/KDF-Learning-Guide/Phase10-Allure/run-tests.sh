#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
# run-tests.sh  —  Phase 10 self-service runner (macOS / Linux)
#
# Double-click in Finder or run from terminal.
# Handles: restore → build → browsers → tests → Allure report → open.
#
# Override any setting by prefixing the command:
#   Headless=false ./run-tests.sh           (watch the browser)
#   TraceMode=Always ./run-tests.sh         (capture trace for every test)
#   TEST_FILTER="Name=01_Login_And_Verify" ./run-tests.sh  (one test)
# ═══════════════════════════════════════════════════════════════════
set -uo pipefail

: "${Browser:=chromium}"
: "${Headless:=true}"
: "${TraceMode:=OnFailure}"
: "${CaptureAllVideos:=false}"
: "${TEST_FILTER:=}"

export Browser Headless TraceMode CaptureAllVideos

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
REPORT_DIR="$SCRIPT_DIR/reports/$TIMESTAMP"

echo "════════════════════════════════════════════════════════"
echo "  KDF Phase 10 — Keyword-Driven Test Run with Allure"
echo "  Browser=$Browser | Headless=$Headless"
echo "  TraceMode=$TraceMode | CaptureAllVideos=$CaptureAllVideos"
[ -n "$TEST_FILTER" ] && echo "  Filter=$TEST_FILTER"
echo "════════════════════════════════════════════════════════"
echo

cd "$SCRIPT_DIR" || { echo "❌ Cannot find project folder."; exit 1; }

# ── Step 1: Restore ──────────────────────────────────────────────
echo "[1/5] Restoring NuGet packages..."
dotnet restore || {
    echo "❌ Restore failed. Is the .NET 8 SDK installed? → dotnet --version"
    exit 1
}

# ── Step 2: Build ─────────────────────────────────────────────────
echo
echo "[2/5] Building..."
dotnet build -c Release --no-restore || {
    echo "❌ Build failed — check compiler errors above."
    exit 1
}

# ── Step 3: Playwright browsers ───────────────────────────────────
echo
echo "[3/5] Installing Playwright browsers (skips if already present)..."
if command -v pwsh >/dev/null 2>&1; then
    pwsh bin/Release/net8.0/playwright.ps1 install --with-deps "$Browser"
else
    echo "  ⚠️  pwsh not found — skipping automatic install."
    echo "     First run only: dotnet tool install -g Microsoft.Playwright.CLI"
    echo "                     playwright install $Browser"
fi

# ── Step 4: Run tests ─────────────────────────────────────────────
echo
echo "[4/5] Running tests..."

FILTER_ARGS=()
[ -n "$TEST_FILTER" ] && FILTER_ARGS=(--filter "$TEST_FILTER")

# Run and capture exit code — we still generate the report even on failure.
dotnet test -c Release --no-build --settings .runsettings "${FILTER_ARGS[@]}"
TEST_EXIT=$?

# ── Step 5: Allure report ─────────────────────────────────────────
echo
echo "[5/5] Generating Allure report..."
mkdir -p "$REPORT_DIR"

# allure-results sits next to the test binary (AppContext.BaseDirectory).
# dotnet build -c Release puts the binary under bin/Release/net8.0/.
ALLURE_RESULTS="bin/Release/net8.0/allure-results"

if command -v allure >/dev/null 2>&1; then
    allure generate "$ALLURE_RESULTS" -o "$REPORT_DIR/allure-report" --clean
    echo
    echo "✅ Report generated: $REPORT_DIR/allure-report"
    echo
    echo "Opening report in browser..."
    echo "(A small local server starts — press Ctrl+C when you are done viewing)"
    allure open "$REPORT_DIR/allure-report"
else
    echo
    echo "⚠️  Allure CLI not found — report not generated."
    echo "   Install once:"
    echo "     macOS:         brew install allure"
    echo "     Any OS (npm):  npm install -g allure-commandline"
    echo
    echo "   Raw results are at: $ALLURE_RESULTS"
    echo "   Run later:  allure serve $ALLURE_RESULTS"
fi

# ── Final summary ─────────────────────────────────────────────────
echo
echo "════════════════════════════════════════════════════════"
if [ "$TEST_EXIT" -eq 0 ]; then
    echo "  ✅  ALL TESTS PASSED"
else
    echo "  ❌  SOME TESTS FAILED"
    echo "     Open the Allure report for step-by-step details,"
    echo "     screenshots, trace files, and test videos."
fi
echo "════════════════════════════════════════════════════════"

exit $TEST_EXIT
