# Phase 09 — NUnit Wiring: TestBase and TestCaseSource

## What you will build

Migrate from a console app to a proper **NUnit test project**. Introduce
`TestBase` (which owns the Playwright browser lifecycle) and `KeywordTests`
(which discovers CSV test folders and runs each as a separate NUnit test).
After this phase, your framework is structurally identical to the PRISM
`TestBase.cs` and `Tests/KeywordTests.cs`.

## Why NUnit instead of a console app?

Console apps are great for learning the mechanics. But they cannot:
- Run multiple tests in isolation (each gets a fresh browser)
- Run tests in parallel
- Report individual test pass/fail to CI pipelines
- Integrate with Allure, VS Test Explorer, dotnet test CLI

NUnit solves all of these by providing a lifecycle (`[SetUp]`/`[TearDown]`)
and a test discovery engine (`[TestCaseSource]`).

## Project structure change

```
Phase09-NUnit/
├── Phase09.csproj          ← NUnit project (not Exe, no <OutputType>)
├── .runsettings             ← browser, headless, timeout config
├── TestBase.cs              ← owns Playwright + browser lifecycle
├── Framework/
│   ├── CsvStepReader.cs
│   ├── KeywordStep.cs
│   ├── VariableManager.cs
│   └── KeywordExecutor.cs
├── Pages/
│   ├── LocatorAttribute.cs
│   ├── LoginPage.cs
│   ├── ProductsPage.cs
│   └── SimpleLocatorResolver.cs
└── Tests/
    ├── KeywordTests.cs
    └── TestData/
        ├── 01_Login_And_Verify/
        │   ├── 01_Login_And_Verify.csv
        │   └── 01_Login_And_Verify_Variables.csv
        └── 02_Add_To_Cart/
            └── 02_Add_To_Cart.csv
```

Each subfolder of `TestData/` is one test case. The folder name becomes the
test's display name in the NUnit test runner.

## `TestBase.cs` — the lifecycle manager

```csharp
public class TestBase
{
    // 'static' = shared across all parallel test instances.
    // IPlaywright is thread-safe — one instance is enough.
    protected static IPlaywright Playwright { get; private set; }

    // 'instance' = each test gets its own browser (required for parallelism).
    protected IBrowser        Browser  { get; private set; }
    protected IBrowserContext Context  { get; private set; }
    protected IPage           Page     { get; private set; }

    // Settings from .runsettings — read once per test in [SetUp].
    protected string BrowserType       { get; private set; }
    protected bool   Headless          { get; private set; }
    protected float  DefaultTimeout    { get; private set; }
    protected float  NavigationTimeout { get; private set; }
```

### The four lifecycle hooks

**`[OneTimeSetUp]` — runs ONCE before the first test:**
```csharp
[OneTimeSetUp]
public static async Task GlobalSetup()
{
    Playwright = await Microsoft.Playwright.Playwright.CreateAsync();
}
```

**`[SetUp]` — runs before EVERY test:**
```csharp
[SetUp]
public async Task Setup()
{
    // Read settings from .runsettings
    Headless = bool.TryParse(TestContext.Parameters["Headless"], out var h) ? h : true;
    DefaultTimeout = float.TryParse(TestContext.Parameters["DefaultTimeout"], out var dt) ? dt : 30000;

    // Launch a fresh browser for this test
    Browser = await Playwright.Chromium.LaunchAsync(new() { Headless = Headless });
    Context = await Browser.NewContextAsync();
    Page    = await Context.NewPageAsync();
    Page.SetDefaultTimeout(DefaultTimeout);
}
```

**`[TearDown]` — runs after EVERY test (even if it failed):**
```csharp
[TearDown]
public async Task TearDown()
{
    await Context.CloseAsync();
    await Browser.CloseAsync();
}
```

**`[OneTimeTearDown]` — runs ONCE after the last test:**
```csharp
[OneTimeTearDown]
public static void GlobalTeardown()
{
    Playwright?.Dispose();
}
```

### Why four hooks and not just two?

`IPlaywright` is expensive to create (it starts a browser-controlling process).
Creating it once per run (via `[OneTimeSetUp]`) and sharing it is significantly
faster than creating it per test. `IBrowser`/`IBrowserContext`/`IPage` must be
per-test because they carry state (cookies, localStorage, history) — sharing
them across tests would cause tests to interfere with each other.

## `KeywordTests.cs` — the test runner

### Test case discovery with `[TestCaseSource]`

```csharp
public static IEnumerable<TestCaseData> GetTestCases()
{
    var root = Path.Combine(TestContext.CurrentContext.WorkDirectory, "TestData");

    return Directory
        .GetDirectories(root)        // each subfolder = one test case
        .Select(dir => new TestCaseData(Path.GetFileName(dir))
            .SetName(Path.GetFileName(dir)));
}
```

`Directory.GetDirectories(root)` returns every subfolder of `TestData/`.
`SetName(...)` controls what the test is called in the test runner, in CI
logs, and in Allure reports.

### The test method

```csharp
[Test]
[TestCaseSource(nameof(GetTestCases))]
public async Task RunCsvTests(string testCaseName)
{
    var basePath      = Path.Combine("TestData", testCaseName);
    var stepsFile     = Directory.GetFiles(basePath, "*.csv")
                            .First(f => !f.Contains("Variables"));
    var variablesFile = Path.Combine(basePath, $"{testCaseName}_Variables.csv");

    VariableManager.Load(variablesFile, TestContext.CurrentContext.Test.ID);

    var steps    = CsvStepReader.ReadSteps(stepsFile).OrderBy(s => s.TestStep).ToList();
    var executor = new KeywordExecutor(Page, testCaseName);   // Page from TestBase.[SetUp]

    foreach (var step in steps)
    {
        await executor.Execute(step);
    }
}
```

`Page` (capital P) comes from `TestBase` — it was created in `[SetUp]`, fully
configured, ready to use. The test method never creates a browser itself.

Notice how short `RunCsvTests` is: read steps, load variables, loop. That's
all a test should do. Everything else (browser lifecycle, screenshots on
failure, Allure reporting) belongs in `TestBase` or `KeywordExecutor`.

## `.runsettings` — externally configurable settings

```xml
<TestRunParameters>
  <Parameter name="Browser"           value="chromium" />
  <Parameter name="Headless"          value="true" />
  <Parameter name="DefaultTimeout"    value="30000" />
  <Parameter name="NavigationTimeout" value="60000" />
</TestRunParameters>
```

Read in `TestBase.Setup()` via `TestContext.Parameters["ParameterName"]`.
Override without touching code: `dotnet test --settings .runsettings` and
change values there, or pass `-e Browser=firefox` on the CI command line.

## Running the tests

```bash
# Run all tests
dotnet test --settings .runsettings

# Run one specific test case
dotnet test --filter "Name=01_Login_And_Verify" --settings .runsettings

# Run in headed mode (watch the browser)
dotnet test --settings .runsettings -- TestRunParameters.Parameter(name="Headless", value="false")
```

## How this maps to PRISM

After completing this phase, open the PRISM framework:

| Phase 09 | PRISM file |
|---|---|
| `TestBase.cs` | `TestBase.cs` (root) |
| `Tests/KeywordTests.cs` | `Tests/KeywordTests.cs` |
| `GetTestCases()` | `GetTestCases()` — identical |
| `RunCsvTests(string testCaseName)` | `RunCsvTests(string testCaseName)` — identical |
| `.runsettings` | `.runsettings` |
| `TestData/<FolderName>/` | `TestData/<FolderName>/` |

The PRISM version adds `[Parallelizable]`, `[FixtureLifeCycle]`, and auth state
handling — but the fundamental structure is exactly what you build here.

---

## Practice Exercises

**Exercise 1 — Add a second test case**
Create `TestData/02_Failed_Login/` with a CSV that uses wrong credentials and
verifies the error message appears. Run with `dotnet test` and confirm both
`01_Login_And_Verify` and `02_Failed_Login` appear as separate tests in the
output.

**Exercise 2 — Parallel execution**
Add these two attributes to `KeywordTests`:
```csharp
[Parallelizable(ParallelScope.All)]
[FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
```
And update `.runsettings` to set `<NumberOfTestWorkers>2</NumberOfTestWorkers>`.
Run both tests and observe: do they run at the same time? Watch two browser
windows open simultaneously. This is exactly the PRISM configuration.

**Exercise 3 — Test name in screenshots**
When `KeywordExecutor.CaptureFailureScreenshot` uses `_testName` to create
the screenshots folder, where does `_testName` come from? Trace it back from
`RunCsvTests` → `new KeywordExecutor(Page, testCaseName)`. Deliberately fail
one test and confirm the screenshot lands in `Screenshots/01_Login_And_Verify/`.

**Exercise 4 — The `[SetUp]` guarantee**
Temporarily add `throw new Exception("Simulate crash")` as the first line of
`RunCsvTests`. Run the tests. Confirm that:
(a) The test fails with your message.
(b) `[TearDown]` still runs (the browser closes — check Task Manager).
(c) `[OneTimeTearDown]` still runs after all tests.
NUnit guarantees `[TearDown]` always runs, regardless of how the test fails.
This is why the Allure attachment code (Phase 10) goes in `[TearDown]` — it
will always execute, even after a crash.
