// Phase 07 — The [Keyword] Attribute and Reflection
//
// Run with: dotnet run
//
// What's new vs Phase 06:
//   - Dictionary<string, Func<>> is GONE
//   - All keyword methods moved into KeywordExecutor class
//   - Each method decorated with [Keyword("Name", "Description")]
//   - InvokeKeyword() uses reflection to find and call the right method
//   - Program.cs is now tiny — just lifecycle + read steps + call Execute()
//   - This structure matches KeywordTests.RunCsvTests() in the PRISM framework

using Microsoft.Playwright;
using Phase07;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 07 — [Keyword] Attribute + Reflection      ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── Show all registered keywords (Exercise 3 in practice) ─────────────
// Scan KeywordExecutor via reflection to list every [Keyword].Name.
// This is what KeywordHtmlGenerator does for the HTML reference page.
var allKeywords = typeof(KeywordExecutor)
    .GetMethods(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)
    .Select(m => m.GetCustomAttribute<KeywordAttribute>())
    .Where(attr => attr != null)
    .Select(attr => $"  • {attr!.Name,-25} {attr.Description}")
    .OrderBy(s => s)
    .ToList();

Console.WriteLine($"📋 Registered keywords ({allKeywords.Count}):");
allKeywords.ForEach(Console.WriteLine);
Console.WriteLine();

// ── Playwright lifecycle ───────────────────────────────────────────────
using var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new() { Headless = false, SlowMo = 300 });
var context = await browser.NewContextAsync();
var page    = await context.NewPageAsync();
page.SetDefaultTimeout(15_000);

// ── Read steps ────────────────────────────────────────────────────────
var filePath = Path.Combine("TestData", "01_Keyword_Attribute_Test.csv");
if (!File.Exists(filePath)) { Console.WriteLine($"❌ Not found: {filePath}"); return; }

var steps = CsvStepReader.ReadSteps(filePath).OrderBy(s => s.TestStep).ToList();
Console.WriteLine($"📄 Loaded {steps.Count} steps\n═══ Running ═══\n");

// ── Create executor and run ────────────────────────────────────────────
// Notice: no keywords registered here. The executor finds them itself.
var executor = new KeywordExecutor(page, "LoginTest");
var passed   = true;

foreach (var step in steps)
{
    Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}");
    try
    {
        await executor.Execute(step);
    }
    catch (Exception ex)
    {
        // The first line of the exception message is always the most useful.
        Console.WriteLine($"  ❌ FAILED: {ex.Message.Split('\n')[0]}");
        passed = false;
        break;
    }
    Console.WriteLine();
}

// ── Cleanup ───────────────────────────────────────────────────────────
await context.CloseAsync();
await browser.CloseAsync();

Console.WriteLine(passed ? "\n✅ ALL STEPS COMPLETED" : "\n❌ TEST FAILED");
Console.WriteLine("See GUIDE.md for practice exercises before moving to Phase 08.");
