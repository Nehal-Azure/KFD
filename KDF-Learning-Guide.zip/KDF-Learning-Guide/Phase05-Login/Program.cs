// Phase 05 — Full Login Test End-to-End
//
// Run with: dotnet run
//
// What's new vs Phase 04:
//   - ProductsPage added (second page object)
//   - _currentPom switches to ProductsPage after clicking LoginButton
//   - Verify_Visible keyword checks element visibility with IsVisibleAsync
//   - DetectCurrentPage() returns the right POM based on the current URL

using Microsoft.Playwright;
using Phase05;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 05 — Full Login Test End-to-End            ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── Playwright lifecycle ────────────────────────────────────────────
using var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new() { Headless = false, SlowMo = 400 });
var context = await browser.NewContextAsync();
var page    = await context.NewPageAsync();

// ── Tracks which page object is "active" right now ──────────────────
// Updated by Click_Button after navigation is detected.
object? currentPom = null;

// ── Keyword dictionary ───────────────────────────────────────────────
var keywords = new Dictionary<string, Func<KeywordStep, Task>>(StringComparer.OrdinalIgnoreCase)
{
    ["NavigateTo_URL"] = async step =>
    {
        Console.WriteLine($"  🌐 Navigate → {step.Item}");
        await page.GotoAsync(step.Item);
        // After navigation, detect which page we are on and set the POM.
        currentPom = DetectCurrentPage(page.Url, page);
        Console.WriteLine($"  ✅ Active POM: {currentPom?.GetType().Name ?? "none"}");
    },

    ["Enter_TextBox"] = async step =>
    {
        var element = GetLocator(step.Item)
            ?? throw new Exception($"Locator '{step.Item}' not found in any page object.");
        Console.WriteLine($"  ⌨️  Fill '{step.Item}' with '{step.Value}'");
        await element.FillAsync(step.Value);
    },

    ["Click_Button"] = async step =>
    {
        var element = GetLocator(step.Item)
            ?? throw new Exception($"Locator '{step.Item}' not found in any page object.");

        Console.WriteLine($"  🖱️  Click '{step.Item}'");
        var urlBefore = page.Url;

        await element.ClickAsync();

        // Wait for any navigation to settle (DOM ready is enough for detection).
        await page.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
        var urlAfter = page.Url;

        if (urlAfter != urlBefore)
        {
            Console.WriteLine($"  🔀 Navigation: {urlBefore}");
            Console.WriteLine($"            → {urlAfter}");
            currentPom = DetectCurrentPage(urlAfter, page);
            Console.WriteLine($"  📋 Active POM → {currentPom?.GetType().Name ?? "unknown"}");
        }
    },

    ["Verify_Visible"] = async step =>
    {
        // Basic visibility check: IsVisibleAsync polls right now, no retry.
        // Phase 06 upgrades this to Playwright's auto-retrying Expect assertion.
        var element = GetLocator(step.Item)
            ?? throw new Exception($"Locator '{step.Item}' not found in any page object.");

        Console.WriteLine($"  👁️  Verify visible: '{step.Item}'");

        var visible = await element.IsVisibleAsync();
        if (!visible)
            throw new Exception($"ASSERTION FAILED: '{step.Item}' is NOT visible.");

        Console.WriteLine($"  ✅ '{step.Item}' is visible");
    },

    ["Capture_Screenshot"] = async step =>
    {
        var folder = "Screenshots";
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"{step.Item}.png");
        await page.ScreenshotAsync(new() { Path = path, FullPage = true });
        Console.WriteLine($"  📸 Screenshot → {path}");
    }
};

// ── Helpers ─────────────────────────────────────────────────────────

// Central locator router — identical to KeywordExecutor.GetLocator() in PRISM.
ILocator? GetLocator(string name) =>
    SimpleLocatorResolver.Resolve(name, page, currentPom);

// Returns the right page object based on the current URL.
// In PRISM this is handled by NavigationTracker which listens to browser events.
object? DetectCurrentPage(string url, IPage page) =>
    url switch
    {
        var u when u.Contains("/inventory") => new ProductsPage(page),
        var u when u.Contains("/cart")      => new ProductsPage(page), // CartPage in Exercise 3
        _                                   => new LoginPage(page)
    };

// ── Read and execute ─────────────────────────────────────────────────
var filePath = Path.Combine("TestData", "01_Full_Login_Test.csv");
if (!File.Exists(filePath)) { Console.WriteLine($"❌ Not found: {filePath}"); return; }

var steps = CsvStepReader.ReadSteps(filePath).OrderBy(s => s.TestStep).ToList();
Console.WriteLine($"📄 Loaded {steps.Count} steps\n═══ Running ═══\n");

var passed = true;
foreach (var step in steps)
{
    Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}");
    if (!keywords.TryGetValue(step.KeywordKey, out var impl))
    {
        Console.WriteLine($"  ❌ Unknown keyword: '{step.KeywordKey}'");
        passed = false; break;
    }
    try   { await impl(step); }
    catch (Exception ex) { Console.WriteLine($"  ❌ FAILED: {ex.Message}"); passed = false; break; }
    Console.WriteLine();
}

await context.CloseAsync();
await browser.CloseAsync();
Console.WriteLine(passed ? "\n✅ ALL STEPS COMPLETED" : "\n❌ TEST FAILED");
