# Final Thoughts — From Phase 01 to Contributing to PRISM

You have reached the end of the learning guide. This document summarises
what you have built, maps every piece to the team's PRISM framework, gives
you a clear path for making your first real contribution, and calls out the
pitfalls most commonly hit by engineers joining a keyword-driven framework
for the first time.

---

## 1. What you built — phase by phase

| Phase | What you added | Key concept learned |
|---|---|---|
| 01 | `CsvStepReader`, `KeywordStep` | A test is just a table of rows. Each row has a verb, a noun, and data. |
| 02 | Dictionary dispatcher | The entire engine at its core: `dictionary[key](step)`. One lookup, one call. |
| 03 | Real Playwright browser | `IPlaywright → IBrowser → IBrowserContext → IPage`. The lifecycle that runs real browsers. |
| 04 | `[Locator]` attribute, `SimpleLocatorResolver` | Selectors live in page objects, not in keywords. The CSV never sees CSS. |
| 05 | `ProductsPage`, `_currentPom` switching | After navigation, the active page object must change so locator resolution finds the right elements. |
| 06 | `Assertions.Expect(...)`, `ExecuteAssertWithScreenshot` | Auto-retrying assertions are inherently more reliable than instant checks. Failures must be self-documenting. |
| 07 | `[Keyword]` attribute + `InvokeKeyword` via reflection | Adding a keyword = adding one method. The registry discovers it automatically. |
| 08 | `VariableManager`, `Capture_Value`, `${token}` syntax | Tests can capture dynamic values at runtime and reference them in later steps. |
| 09 | `TestBase` (`[OneTimeSetUp]`/`[SetUp]`/`[TearDown]`/`[OneTimeTearDown]`), `KeywordTests` | NUnit manages the lifecycle. Each test gets an isolated browser. Failures always clean up. |
| 10 | `[AllureNUnit]`, `AllureApi.Step`, trace + video + screenshot | Every test case is a clickable, step-by-step report with visual evidence attached to failures. |

---

## 2. The complete PRISM framework map

Open the PRISM framework and find these files. Every component you built has
a direct, named counterpart:

### Data and reading

| Your file | PRISM file | Notes |
|---|---|---|
| `Framework/KeywordStep.cs` | `Framework/Data/KeywordStep.cs` | Identical structure |
| `Framework/CsvStepReader.cs` | `Framework/Data/CsvStepReader.cs` | PRISM adds `KeywordValidation.Normalize()` on Item — see Pitfall 2 |
| `Tests/TestData/<Folder>/` | `Tests/TestData/<Folder>/` | Identical folder-per-test convention |
| `_Variables.csv` | `<TestName>_Variables.csv` | Identical naming convention |

### Engine

| Your file | PRISM file | Notes |
|---|---|---|
| `Framework/KeywordAttribute.cs` | `Framework/Engine/KeywordAttribute.cs` (named `KKeywordAttribute.cs` — typo in filename) | Identical code |
| `Framework/KeywordExecutor.cs` | `Framework/Engine/KeywordExecutor.cs` | PRISM has 25+ additional keywords (`Set_Dropdown`, `Set_Date`, `Press_Key`, etc.) |
| `InvokeKeyword(key, step)` | `InvokeKeyword(key, step)` | Identical dispatch mechanism |
| `ExecuteAssertWithScreenshot(Func<Task>, step)` | `ExecuteAssertWithScreenshot(Func<Task>, KeywordStep)` | Identical pattern |
| `CaptureFailureScreenshot(name)` + Allure attach | `CaptureFailureScreenshot(name)` + `AllureApi.AddAttachment` | Identical after Phase10 changes |
| `_currentPage` field | `_currentPage` field | Identical |
| `_currentPom` field | `_currentPOM` field | Same concept, slightly different casing |

### Locators and pages

| Your file | PRISM file | Notes |
|---|---|---|
| `Pages/LocatorAttribute.cs` | `Framework/Locators/LocatorAttribute.cs` | Identical |
| `Pages/SimpleLocatorResolver.cs` | `Framework/Locators/SimpleLocatorResolver.cs` | PRISM version does assembly scanning instead of a fixed `_pageTypes` array |
| `Pages/LoginPage.cs` | `Pages/LoginPage.cs` | PRISM selectors target a different real application |
| `Pages/ProductsPage.cs` | `Pages/WorkPage.cs` | Different application, same pattern |

### NUnit and reporting

| Your file | PRISM file | Notes |
|---|---|---|
| `TestBase.cs` | `TestBase.cs` | PRISM adds auth state (`auth.json`). Your Phase10 version has `[AllureNUnit]` correctly placed — the PRISM version had it in comments but not on the class. |
| `Tests/KeywordTests.cs` | `Tests/KeywordTests.cs` | Identical structure. PRISM adds `CreateAuthState` test. |
| `Framework/VariableManager.cs` | `VariableManager.cs` | PRISM version uses `ConcurrentDictionary` keyed by test ID — identical to your Phase09/10 version. |
| `run-tests.sh` / `run-tests.bat` | From the Allure integration review | Identical. PRISM's scripts also add an `auth.json` guard check. |

### PRISM-only components you have not built yet

Understanding what each one does is enough to work with them confidently:

| PRISM file | What it does | Your closest equivalent |
|---|---|---|
| `Framework/Navigation/NavigationTracker.cs` | Detects new tab / closed tab / same-tab navigation using browser context events. More robust than URL inspection. | Your `DetectCurrentPage(url)` URL switch in Phase05 |
| `Framework/Navigation/NavigationResult.cs` | Data class holding before/after URL, page reference, navigation type enum | Your return value from `DetectCurrentPage` |
| `Framework/Security/CryptoHelper.cs` | AES-256-CBC decryption using SHA-256 of a string key | Not covered — only relevant when using encrypted credentials |
| `Framework/Services/CredentialProvider.cs` | Reads `credentials.json`, decrypts with `CryptoHelper`, returns `(username, password)` tuple | The commented-out `LoginAs_Role` keyword in PRISM |
| `Framework/Documentation/KeywordHtmlGenerator.cs` | Scans `KeywordExecutor` via reflection and writes a searchable HTML reference page | Your Phase07 Exercise 3: "List all registered keywords" |
| `Framework/Locators/LocatorMap.cs` | Hard-coded fallback dictionary of selectors for elements not yet in any page object | You explicitly removed this fallback in Phase07; PRISM still has it as a bridge during migration |

---

## 3. How to make your first contribution to PRISM

### Adding a new keyword (the most common task)

1. Open `Framework/Engine/KeywordExecutor.cs`.
2. Write a public method with this exact signature:
   ```csharp
   [Keyword("YourAction_YourType", "What this keyword does, in one sentence.")]
   public async Task YourMethodName(KeywordStep step)
   {
       // Your implementation here.
       // Use GetLocator(step.Item) to resolve element names.
       // Use step.Value for any input data.
       // Wrap assertions in ExecuteAssertWithScreenshot(..., step).
   }
   ```
3. That is the entire change. `InvokeKeyword` finds it via reflection automatically.
4. Add a row to a test CSV to try it:
   ```
   10,YourAction,YourType,ElementName,SomeValue,Test your new keyword
   ```
5. Run the test. If the keyword is not found, the error message lists all
   available keywords — use that list to verify your `[Keyword]` name matches
   the `Action_Type` you wrote in the CSV.

### Adding a new page object

1. Create a new file in `Pages/`, e.g. `Pages/CartPage.cs`:
   ```csharp
   public class CartPage
   {
       private readonly IPage _page;
       public CartPage(IPage page) { _page = page; }

       [Locator("CartTitle", "The 'Your Cart' heading", ".title")]
       public ILocator CartTitle => _page.Locator(".title");

       [Locator("CheckoutButton", "Proceed to checkout button", "[data-test='checkout']")]
       public ILocator CheckoutButton => _page.Locator("[data-test='checkout']");
   }
   ```
2. The PRISM `SimpleLocatorResolver` uses assembly scanning — it finds
   `CartPage` automatically because it scans every class in the `Pages`
   namespace. You do not need to register it anywhere. Add a `Verify_Visible`
   step in a CSV using `"CartTitle"` and it just works.
3. If `DetectCurrentPage` (or `NavigationTracker` in PRISM) needs to switch
   to this page after navigation, add it to that logic:
   ```csharp
   var u when u.Contains("/cart") => new CartPage(_currentPage),
   ```

### Adding a new test case

1. Create a new subfolder in `Tests/TestData/`:
   ```
   Tests/TestData/03_Checkout_Flow/
     03_Checkout_Flow.csv
     03_Checkout_Flow_Variables.csv   (optional)
   ```
2. Write the CSV steps using existing keywords. If you need a new keyword
   for this test, add it first (see above).
3. Run `dotnet test --filter "Name=03_Checkout_Flow"` to try it alone
   before running the full suite.
4. `KeywordTests.GetTestCases()` picks up the new folder automatically.
   Nothing else to register.

---

## 4. Common pitfalls — and how to avoid them

### Pitfall 1 — `[AllureNUnit]` missing from `TestBase`

**Symptom:** `allure-results/` folder is empty after the run, or the folder
does not appear at all.

**Cause:** The attribute exists in `using Allure.NUnit;` imports and in a
comment, but is not placed above the `TestBase` class declaration.

**Fix:** Check the class declaration reads exactly:
```csharp
[AllureNUnit]
public class TestBase { ... }
```
Not above the namespace. Not on `KeywordTests`. On `TestBase` itself.

---

### Pitfall 2 — `Normalize()` strips spaces from Item; locators use spaces

**Symptom:** A CSV step with `Item=Log Out` fails with "Locator 'LogOut' not
found in any page object" even though `WorkPage` has
`[Locator("Log Out", ...)]`.

**Cause:** `CsvStepReader` in PRISM calls `KeywordValidation.Normalize(parts[3])`
which removes all spaces from the `Item` column. "Log Out" → "LogOut".
But `[Locator].Name` on the page object property is `"Log Out"` (with space).
`SimpleLocatorResolver` does case-insensitive comparison but not
space-normalised comparison, so `"LogOut" != "Log Out"`.

**Fix:** Either keep spaces in `[Locator]` names consistent with the CSV
(both use space, or both drop it), or update `SimpleLocatorResolver` to
strip spaces before comparison:
```csharp
attr.Name.Replace(" ", "").Equals(name.Replace(" ", ""), StringComparison.OrdinalIgnoreCase)
```

---

### Pitfall 3 — Video file is empty or not created

**Symptom:** `AllureApi.AddAttachment` for the video throws, or the attached
video is 0 bytes.

**Cause:** The browser context was closed by `Browser.CloseAsync()` before
`Context.CloseAsync()`, or the context was garbage-collected before being
explicitly closed. Playwright finalises the `.webm` file only when the context
is closed.

**Fix:** Always close in this exact order in `[TearDown]`:
```csharp
// 1. Stop tracing
await Context.Tracing.StopAsync(...);
// 2. Close context — finalises .webm
await Context.CloseAsync();
// 3. THEN read/attach the video file
var videoFile = Directory.GetFiles(_videoDir, "*.webm").FirstOrDefault();
AllureApi.AddAttachment(..., videoFile);
// 4. Close browser last
await Browser.CloseAsync();
```

---

### Pitfall 4 — `DefaultTimeout = 0` disables all timeouts

**Symptom:** Tests hang indefinitely instead of failing after a timeout. A
hanging CI build with no output is the typical sign.

**Cause:** `DefaultTimeout` and `NavigationTimeout` are declared as `float`
fields with no initialiser value. In C#, `float` defaults to `0`. If the
`[SetUp]` method fails to read them from `.runsettings` (because the
`.runsettings` parameter name is missing or the file was not passed with
`--settings`), `Page.SetDefaultTimeout(0)` is called, which in Playwright
means "wait forever."

**Fix:** Always provide explicit fallback values in the `TryParse` calls:
```csharp
DefaultTimeout = float.TryParse(
    TestContext.Parameters["DefaultTimeout"], out var dt) ? dt : 30_000;
```
And always run with `dotnet test --settings .runsettings` rather than plain
`dotnet test`.

---

### Pitfall 5 — Parallel tests corrupting `VariableManager`

**Symptom:** Intermittent failures where step variable values are wrong or
missing, but only when running more than one test at a time. Works fine in
sequential mode.

**Cause:** An older `static Dictionary<string, string>` `VariableManager`
where `Load()` calls `_variables.Clear()`. Test B's `Load()` wipes Test A's
variables while Test A is mid-execution.

**Fix:** The Phase09/10 `VariableManager` uses
`ConcurrentDictionary<string, Dictionary<string, string>>` keyed by
`TestContext.CurrentContext.Test.ID` — each test has its own isolated store.
Make sure every call to `Load`, `Resolve`, `Set`, and `Cleanup` passes
`TestContext.CurrentContext.Test.ID` as the `testId` parameter.

---

### Pitfall 6 — Unknown keyword error with no useful message

**Symptom:** A test fails with a bare `"Keyword not implemented: 'Set_Dropdown'"`.
The error gives no guidance on where to add it.

**Fix:** The Phase07/08/09/10 `InvokeKeyword` already lists all available
keywords in the error message. If PRISM's version does not, add the same:
```csharp
throw new Exception(
    $"Keyword not implemented: '{key}'\n" +
    $"Available: {string.Join(", ", available)}");
```

---

### Pitfall 7 — A new test folder not discovered by `GetTestCases()`

**Symptom:** You create `Tests/TestData/04_New_Test/04_New_Test.csv` but
`dotnet test` does not show a test named `04_New_Test`.

**Cause 1:** The CSV file is not copied to the output directory.
Open the `.csproj` and confirm:
```xml
<None Include="Tests\TestData\**\*.csv">
  <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
</None>
```
If missing, add it and rebuild.

**Cause 2:** `GetTestCases()` uses `TestContext.CurrentContext.WorkDirectory`
which points to where `dotnet test` is invoked from. If you invoke from a
different directory, the `TestData` path resolution changes. Run from the
project folder or use `AppContext.BaseDirectory` instead.

**Cause 3:** The new folder has a CSV file whose name contains `"Variables"`.
`GetTestCases` looks for directories, not files — so the folder will be
found. But inside `RunCsvTests`, the steps file is located with:
```csharp
.FirstOrDefault(f => !Path.GetFileName(f).Contains("Variables"))
```
A steps file accidentally named `04_Variables_Test.csv` would be skipped.
Rename it so the word "Variables" only appears in the variables file name.

---

## 5. What to read next

With this guide complete and PRISM fully mapped, your natural next areas are:

**Deepen your Playwright knowledge**
- `playwright.dev/dotnet` — the official C# Playwright docs cover every API
  you saw in the framework (locators, assertions, tracing, network interception).

**Understand NavigationTracker**
- Read `Framework/Navigation/NavigationTracker.cs` in PRISM with fresh eyes.
  You now know what problem it solves (Phase 05's `DetectCurrentPage`).
  The event-based approach using `context.WaitForPageAsync()` and subscribing
  to `page.Close` is the production-quality version of URL inspection.

**Write the CSV linter**
- The most immediately useful tool you can add to PRISM: a console app that
  reads every CSV in `TestData/`, checks every `Action_Type` keyword key
  exists in `KeywordExecutor`, and checks every `PageObject.Element` resolves
  in `SimpleLocatorResolver`. Run it as a build step. It catches typos in
  seconds rather than after a full browser run.

**Read the Allure documentation**
- `allurereport.org/docs/nunit` — the NUnit integration docs show advanced
  features: `[AllureLink]`, `[AllureIssue]`, history trending, retry support,
  and environment information.

---

## 6. One-paragraph summary to share with a colleague

A keyword-driven framework stores test steps in a CSV file instead of in
C# code. Each row names an action (`Click`, `Verify`, `Enter`) and a target
type (`Button`, `Visible`, `TextBox`), forming a keyword key (`Click_Button`)
that the engine looks up via reflection to find the right C# method. Element
names in the CSV are logical names (`LoginButton`, `ProductsTitle`) that the
Page Object Model resolves to real Playwright selectors — the CSV never
contains CSS. Variables loaded from a companion file, or captured at runtime
with `Capture_Value`, let tests handle dynamic data using `${token}` syntax
resolved before each step runs. NUnit's `[TestCaseSource]` turns each CSV
folder into a separate, independently reportable test, run in parallel with
isolated browser sessions. Allure wraps each step in a labelled report entry
and attaches screenshots, Playwright traces, and video to every failure — so
the complete evidence for any bug is available in one place, accessible to
anyone with a web browser, without running the tests again.

---

*This guide covers 109 files across 10 phases. If you work through every
phase and complete every practice exercise, you will have built the same
framework three times (console app → NUnit without Allure → NUnit with
Allure), each time understanding more of the design decisions. The PRISM
framework will hold no surprises.*
