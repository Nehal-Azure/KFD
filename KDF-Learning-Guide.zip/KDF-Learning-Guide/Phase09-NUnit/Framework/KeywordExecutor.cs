// Phase09-NUnit/Framework/KeywordExecutor.cs
//
// Complete KeywordExecutor for Phase 09.
// All keywords from Phases 07 and 08 are present.
// The Execute() method now resolves variables before dispatch.
// CaptureFailureScreenshot uses the test name for folder isolation.

using System.Reflection;
using Microsoft.Playwright;
using NUnit.Framework;

namespace Phase09;

public class KeywordExecutor
{
    private IPage    _currentPage;
    private object?  _currentPom;
    private readonly string _testName;

    public KeywordExecutor(IPage page, string testName)
    {
        _currentPage = page;
        _testName    = testName;
    }

    // ── Entry point ────────────────────────────────────────────────────────
    public async Task Execute(KeywordStep step)
    {
        // Resolve ${token} BEFORE the keyword sees the values.
        // Every keyword is automatically variable-aware with no extra code.
        step.Item  = VariableManager.Resolve(step.Item,
                         TestContext.CurrentContext.Test.ID);
        step.Value = VariableManager.Resolve(step.Value,
                         TestContext.CurrentContext.Test.ID);

        await InvokeKeyword($"{step.Action}_{step.Type}", step);
    }

    // ── Reflection dispatcher ──────────────────────────────────────────────
    private async Task InvokeKeyword(string key, KeywordStep step)
    {
        var method = GetType()
            .GetMethods(BindingFlags.Public | BindingFlags.Instance)
            .FirstOrDefault(m =>
            {
                var attr = m.GetCustomAttribute<KeywordAttribute>();
                return attr != null &&
                       attr.Name.Equals(key, StringComparison.OrdinalIgnoreCase);
            });

        if (method == null)
        {
            var available = GetType()
                .GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .Select(m => m.GetCustomAttribute<KeywordAttribute>()?.Name)
                .Where(n => n != null)
                .OrderBy(n => n);

            throw new Exception(
                $"Keyword not implemented: '{key}'\n" +
                $"Available: {string.Join(", ", available)}");
        }

        var result = method.Invoke(this, new object[] { step });
        if (result is Task task) await task;
    }

    // ══════════════════════════════════════════════════════════════════════
    // KEYWORDS
    // ══════════════════════════════════════════════════════════════════════

    [Keyword("NavigateTo_URL", "Navigates to the URL in Item.")]
    public async Task NavigateToUrl(KeywordStep step)
    {
        Console.WriteLine($"  🌐 Navigate → {step.Item}");
        await _currentPage.GotoAsync(step.Item);
        await _currentPage.WaitForLoadStateAsync(LoadState.DOMContentLoaded);
        _currentPom = DetectCurrentPage(_currentPage.Url);
    }

    [Keyword("Enter_TextBox", "Types Value into the field named by Item.")]
    public async Task EnterTextBox(KeywordStep step)
    {
        if (string.IsNullOrWhiteSpace(step.Item))
            throw new ArgumentException("Enter_TextBox: Item (field name) is required.");
        if (string.IsNullOrWhiteSpace(step.Value))
            throw new ArgumentException($"Enter_TextBox: Value (text to type) is required. Item='{step.Item}'");

        Console.WriteLine($"  ⌨️  Fill '{step.Item}' = '{step.Value}'");
        await GetLocator(step.Item).FillAsync(step.Value);
    }

    [Keyword("Click_Button", "Clicks the element named by Item. Detects navigation.")]
    public async Task ClickButton(KeywordStep step)
    {
        Console.WriteLine($"  🖱️  Click '{step.Item}'");
        var urlBefore = _currentPage.Url;
        await GetLocator(step.Item).ClickAsync();
        await _currentPage.WaitForLoadStateAsync(LoadState.DOMContentLoaded);

        if (_currentPage.Url != urlBefore)
        {
            _currentPom = DetectCurrentPage(_currentPage.Url);
            Console.WriteLine($"  🔀 POM → {_currentPom?.GetType().Name}");
        }
    }

    [Keyword("Click_Item", "Clicks any element named by Item (same as Click_Button).")]
    public async Task ClickItem(KeywordStep step) => await ClickButton(step);

    [Keyword("Verify_Visible", "Asserts element named by Item is visible. Auto-retries.")]
    public async Task VerifyVisible(KeywordStep step)
    {
        Console.WriteLine($"  👁️  Verify visible: '{step.Item}'");
        var e = GetLocator(step.Item);
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(e).ToBeVisibleAsync(), step);
        Console.WriteLine("  ✅ Visible");
    }

    [Keyword("Verify_Hidden", "Asserts element named by Item is NOT visible. Auto-retries.")]
    public async Task VerifyHidden(KeywordStep step)
    {
        Console.WriteLine($"  🙈 Verify hidden: '{step.Item}'");
        var e = GetLocator(step.Item);
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(e).ToBeHiddenAsync(), step);
        Console.WriteLine("  ✅ Hidden");
    }

    [Keyword("Verify_Text", "Asserts element named by Item contains text in Value. Auto-retries.")]
    public async Task VerifyText(KeywordStep step)
    {
        Console.WriteLine($"  📝 Verify text '{step.Item}' ∋ '{step.Value}'");
        var e = GetLocator(step.Item);
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(e).ToContainTextAsync(step.Value), step);
        Console.WriteLine("  ✅ Text confirmed");
    }

    [Keyword("Verify_Enabled", "Asserts element named by Item is enabled. Auto-retries.")]
    public async Task VerifyEnabled(KeywordStep step)
    {
        Console.WriteLine($"  ⚡ Verify enabled: '{step.Item}'");
        var e = GetLocator(step.Item);
        await ExecuteAssertWithScreenshot(
            async () => await Assertions.Expect(e).ToBeEnabledAsync(), step);
        Console.WriteLine("  ✅ Enabled");
    }

    [Keyword("Capture_Screenshot", "Saves a full-page screenshot. Item = filename.")]
    public async Task CaptureScreenshot(KeywordStep step)
    {
        var name   = string.IsNullOrWhiteSpace(step.Item) ? "screenshot" : step.Item;
        var folder = Path.Combine("Screenshots", Sanitize(_testName));
        Directory.CreateDirectory(folder);
        var path   = Path.Combine(folder, $"{name}.png");
        await _currentPage.ScreenshotAsync(new() { Path = path, FullPage = true });
        Console.WriteLine($"  📸 Screenshot → {path}");
    }

    [Keyword("Capture_Value",
        "Reads text of element named by Item. Stores under the key in Value.")]
    public async Task CaptureValue(KeywordStep step)
    {
        if (string.IsNullOrWhiteSpace(step.Item))
            throw new ArgumentException("Capture_Value: Item (element name) is required.");
        if (string.IsNullOrWhiteSpace(step.Value))
            throw new ArgumentException("Capture_Value: Value (variable name) is required.");

        var e    = GetLocator(step.Item);
        var text = await e.InnerTextAsync();
        if (string.IsNullOrEmpty(text)) text = await e.InputValueAsync();

        VariableManager.Set(step.Value, text ?? string.Empty,
            TestContext.CurrentContext.Test.ID);
        Console.WriteLine($"  📌 Stored '{step.Item}' = \"{text}\" → ${{{step.Value}}}");
    }

    [Keyword("Pause_Seconds", "Waits for the number of seconds in Value.")]
    public async Task PauseSeconds(KeywordStep step)
    {
        if (!int.TryParse(step.Value, out var seconds))
            throw new ArgumentException($"Pause_Seconds: Value must be an integer. Got: '{step.Value}'");
        Console.WriteLine($"  ⏸  Pause {seconds}s");
        await Task.Delay(seconds * 1000);
    }

    // ══════════════════════════════════════════════════════════════════════
    // PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════════════

    private ILocator GetLocator(string name)
    {
        var locator = SimpleLocatorResolver.Resolve(name, _currentPage, _currentPom);
        return locator
            ?? throw new Exception(
                $"Locator '{name}' not found in any page object.\n" +
                $"Add [Locator(\"{name}\", ...)] to the appropriate page class.");
    }

    private async Task ExecuteAssertWithScreenshot(Func<Task> assert, KeywordStep step)
    {
        try   { await assert(); }
        catch { await CaptureFailureScreenshot($"{step.Action}_{step.Type}_{step.Item}"); throw; }
    }

    private async Task CaptureFailureScreenshot(string name)
    {
        try
        {
            var folder    = Path.Combine("Screenshots", "Failures", Sanitize(_testName));
            Directory.CreateDirectory(folder);
            var path      = Path.Combine(folder, $"FAIL_{Sanitize(name)}_{DateTime.Now:HHmmss_fff}.png");
            await _currentPage.ScreenshotAsync(new() { Path = path, FullPage = true });
            Console.WriteLine($"  📸 FAILURE screenshot → {path}");
        }
        catch (Exception e) { Console.WriteLine($"  ⚠️  Screenshot failed: {e.Message}"); }
    }

    private object? DetectCurrentPage(string url) =>
        url switch
        {
            var u when u.Contains("/inventory") => new ProductsPage(_currentPage),
            _                                   => new LoginPage(_currentPage)
        };

    private static string Sanitize(string s) =>
        string.Concat(s.Select(c => char.IsLetterOrDigit(c) || c is '-' or '_' ? c : '_'));
}
