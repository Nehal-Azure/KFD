// Phase 04 — Page Object Model with the [Locator] Attribute
//
// Run with: dotnet run
//
// What's new vs Phase 03:
//   - [Locator] attribute decorates LoginPage properties with a logical name
//   - SimpleLocatorResolver resolves "Username" → LoginPage.Username → ILocator
//   - Keywords no longer contain hard-coded selectors (#user-name, #password)
//   - A selector change only needs updating in LoginPage.cs — not in the keywords

using Microsoft.Playwright;
using Phase04;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 04 — Page Object + [Locator] Attribute     ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── Playwright lifecycle ───────────────────────────────────────────────────
using var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new() { Headless = false, SlowMo = 400 });
var context = await browser.NewContextAsync();
var page    = await context.NewPageAsync();

// ── The active page object — updated when keywords know which screen we're on
// `object?` lets us hold any page type without a common interface.
// Phase 07 shows why this becomes a pattern; for now, null = no POM active yet.
object? currentPom = null;

// ── Keyword dictionary — now selector-free ────────────────────────────────
// Every keyword calls GetLocator(step.Item) instead of page.Locator("#something").
// The resolver finds the selector by scanning page objects — keywords stay clean.

var keywords = new Dictionary<string, Func<KeywordStep, Task>>(StringComparer.OrdinalIgnoreCase)
{
    ["NavigateTo_URL"] = async step =>
    {
        Console.WriteLine($"  🌐 Navigate → {step.Item}");
        await page.GotoAsync(step.Item);
        Console.WriteLine($"  ✅ Title: {await page.TitleAsync()}");
    },

    ["Enter_TextBox"] = async step =>
    {
        // GetLocator asks SimpleLocatorResolver to find "Username" on any page object
        var element = GetLocator(step.Item)
            ?? throw new Exception($"Locator '{step.Item}' not found in any page object.");

        Console.WriteLine($"  ⌨️  Fill '{step.Item}' with '{step.Value}'");
        await element.FillAsync(step.Value);
    },

    ["Click_Button"] = async step =>
    {
        var element = GetLocator(step.Item)
            ?? throw new Exception($"Locator '{step.Item}' not found in any page object.");

        Console.WriteLine($"  🖱️  Click '{step.Item}'");
        await element.ClickAsync();

        // After login the page changes — update the current POM to ProductsPage
        // (You will add ProductsPage in Exercise 1 of the practice section.)
    },

    ["Capture_Screenshot"] = async step =>
    {
        var folder = "Screenshots";
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"{step.Item}.png");
        await page.ScreenshotAsync(new() { Path = path, FullPage = true });
        Console.WriteLine($"  📸 Screenshot → {Path.GetFullPath(path)}");
    }
};

// ── Locator helper — the central routing point ───────────────────────────
// This is exactly what KeywordExecutor.GetLocator() does in the PRISM framework.
// The current POM is searched first; if not found, all known page types are scanned.
ILocator? GetLocator(string name)
{
    var locator = SimpleLocatorResolver.Resolve(name, page, currentPom);

    if (locator == null)
    {
        Console.WriteLine($"  ⚠️  WARNING: Locator '{name}' not found in any page object.");
        Console.WriteLine($"     Add a property with [Locator(\"{name}\",...)] to the right page class.");
    }

    return locator;
}

// ── Read and execute steps ────────────────────────────────────────────────
var filePath = Path.Combine("TestData", "01_Locator_Demo.csv");
if (!File.Exists(filePath))
{
    Console.WriteLine($"❌ File not found: {filePath}");
    await browser.CloseAsync();
    return;
}

// Before execution: set the active POM to LoginPage so it is searched first.
// Once you know which screen you are starting on, set it here.
currentPom = new LoginPage(page);

var steps = CsvStepReader.ReadSteps(filePath).OrderBy(s => s.TestStep).ToList();
Console.WriteLine($"📄 Loaded {steps.Count} steps\n");
Console.WriteLine("═══ Running ═══\n");

var passed = true;

foreach (var step in steps)
{
    Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}");

    if (!keywords.TryGetValue(step.KeywordKey, out var impl))
    {
        Console.WriteLine($"  ❌ Unknown keyword: '{step.KeywordKey}'");
        passed = false;
        break;
    }

    try
    {
        await impl(step);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"  ❌ FAILED: {ex.Message}");
        passed = false;
        break;
    }

    Console.WriteLine();
}

// ── Cleanup ────────────────────────────────────────────────────────────────
await context.CloseAsync();
await browser.CloseAsync();

Console.WriteLine(passed ? "\n✅ ALL STEPS COMPLETED" : "\n❌ TEST FAILED");
Console.WriteLine("See GUIDE.md for practice exercises before moving to Phase 05.");
