// Phase 03 — Real Browser with Playwright
//
// Run with: dotnet run
//
// FIRST TIME SETUP (run once):
//   dotnet restore
//   pwsh bin/Debug/net8.0/playwright.ps1 install chromium
//
// What's new vs Phase 02:
//   - Microsoft.Playwright NuGet package added
//   - IPlaywright, IBrowser, IBrowserContext, IPage lifecycle created
//   - NavigateTo_URL and Capture_Screenshot use real Playwright calls
//   - A real Chromium window opens and navigates to SauceDemo

using Microsoft.Playwright;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 03 — Real Browser with Playwright          ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── 1. Create the Playwright lifecycle objects ────────────────────────────
//
// In Phase 09, TestBase manages this. Here we manage it ourselves so
// you can see exactly what TestBase is doing.
Console.WriteLine("🚀 Launching browser...");

using var playwright = await Playwright.CreateAsync();

var browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
{
    Headless = false,       // change to true for no-window mode
    SlowMo   = 500          // 500ms pause between actions — makes it watchable
});

var context = await browser.NewContextAsync(new BrowserNewContextOptions
{
    ViewportSize = null     // use the OS default window size
});

var page = await context.NewPageAsync();

Console.WriteLine("✅ Browser ready");
Console.WriteLine();

// ── 2. Build the keyword dictionary ──────────────────────────────────────
//
// Same structure as Phase 02, but now the lambdas call real Playwright methods.
// Note how `page` is captured by the lambda (a "closure") — the lambda can
// use `page` even though it is not a parameter to the lambda itself.

var keywords = new Dictionary<string, Func<KeywordStep, Task>>(
    StringComparer.OrdinalIgnoreCase)
{
    ["NavigateTo_URL"] = async step =>
    {
        Console.WriteLine($"  🌐 Navigating to: {step.Item}");

        // GotoAsync sends the browser to the URL and waits for the
        // page's "load" event — no sleep needed.
        await page.GotoAsync(step.Item);

        // TitleAsync reads the current page's <title> element.
        var title = await page.TitleAsync();
        Console.WriteLine($"  ✅ Page loaded. Title: '{title}'");
    },

    ["Capture_Screenshot"] = async step =>
    {
        // Build a safe filename from the Item column.
        var fileName = string.IsNullOrWhiteSpace(step.Item) ? "screenshot" : step.Item;
        var folder   = "Screenshots";
        Directory.CreateDirectory(folder);
        var path = Path.Combine(folder, $"{fileName}.png");

        // ScreenshotAsync captures the current state of the page.
        // FullPage = true scrolls and captures everything, not just the viewport.
        await page.ScreenshotAsync(new PageScreenshotOptions
        {
            Path     = path,
            FullPage = true
        });

        Console.WriteLine($"  📸 Screenshot saved: {Path.GetFullPath(path)}");
    }

    // You will add more keywords here in the practice exercises.
    // Hint for Exercise 2: ["Click_Button"] = async step => { await page.ClickAsync("#login-button"); }
};

// ── 3. Read and execute steps ─────────────────────────────────────────────
var filePath = Path.Combine("TestData", "01_Navigate_Screenshot.csv");

if (!File.Exists(filePath))
{
    Console.WriteLine($"❌ Cannot find: {filePath}");
    await browser.CloseAsync();
    playwright.Dispose();
    return;
}

var steps = CsvStepReader.ReadSteps(filePath)
    .OrderBy(s => s.TestStep)
    .ToList();

Console.WriteLine($"📄 Loaded {steps.Count} steps");
Console.WriteLine();
Console.WriteLine("═══ Running Test ═══");

var passed = true;

foreach (var step in steps)
{
    Console.WriteLine();
    Console.WriteLine($"▶ Step {step.TestStep}: {step.KeywordKey}");

    if (!keywords.TryGetValue(step.KeywordKey, out var impl))
    {
        Console.WriteLine($"  ❌ Unknown keyword: '{step.KeywordKey}'");
        passed = false;
        break;
    }

    try
    {
        await impl(step);
    }
    catch (Exception ex)
    {
        // In Phase 06 you will add screenshot-on-failure here.
        Console.WriteLine($"  ❌ FAILED: {ex.Message}");
        passed = false;
        break;
    }
}

// ── 4. Clean up the Playwright lifecycle ─────────────────────────────────
//
// IMPORTANT: close in this order — context before browser.
// In Phase 10, context is closed explicitly before reading the video file.
Console.WriteLine();
Console.WriteLine("🧹 Closing browser...");
await context.CloseAsync();
await browser.CloseAsync();
// playwright.Dispose() is called automatically by 'using var'

Console.WriteLine();
Console.WriteLine("═══ Result ═══");
Console.WriteLine(passed ? "✅ ALL STEPS COMPLETED" : "❌ TEST FAILED");
