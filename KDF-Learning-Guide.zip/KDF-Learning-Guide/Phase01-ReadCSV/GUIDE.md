# Phase 01 — Read a CSV and Print to Console

## What you will build

A tiny console program that reads a test-step CSV file and prints each row
to the terminal. No browser, no Playwright, no NuGet packages. Just C# and
a file.

## Why start here?

In the PRISM framework, **every test case is a CSV file**. Before you can
understand anything else — the executor, the keywords, the page objects —
you need to be completely comfortable with how a CSV row becomes a C# object.
That is the only thing this phase teaches.

## The CSV format

Open `TestData/01_First_Test.csv`. It looks like this:

```
TestStep,Action,Type,Item,Value,Comments
01,NavigateTo,URL,https://www.saucedemo.com,,Navigate to login page
02,Enter,TextBox,Username,standard_user,Type the username
03,Enter,TextBox,Password,secret_sauce,Type the password
04,Click,Button,LoginButton,,Click the log in button
05,Verify,Visible,ProductsHeading,,The products heading should be visible
```

Column meanings:
- **TestStep** — zero-padded number used for ordering (`01`, `02`...)
- **Action** — the "verb" of what to do (`Navigate`, `Enter`, `Click`, `Verify`)
- **Type** — the "noun" of what to act on (`URL`, `TextBox`, `Button`, `Visible`)
- **Item** — the logical name of the element or the URL/value to act on
- **Value** — extra data the action needs (e.g. text to type)
- **Comments** — human notes, never used by the engine

The engine combines `Action` and `Type` with an underscore to form a
**keyword key**: `"Enter_TextBox"`, `"Click_Button"`, `"Verify_Visible"`.
That key is looked up in the keyword registry to find the right code to run.
You do not need the registry yet — just understand the concept.

## The C# model

A `KeywordStep` object represents one row. Create one property per column:

```
CSV row:  01,Enter,TextBox,Username,standard_user,Type the username
             ^     ^       ^         ^             ^
             |     |       |         |             +-- Comments
             |     |       |         +--------------- Value
             |     |       +------------------------- Item
             |     +--------------------------------- Type
             +-----------------------------------------Action
```

## Code walkthrough

### `KeywordStep.cs` — the data model

```csharp
public class KeywordStep
{
    public string TestStep  { get; set; }   // "01"
    public string Action    { get; set; }   // "Enter"
    public string Type      { get; set; }   // "TextBox"
    public string Item      { get; set; }   // "Username"
    public string Value     { get; set; }   // "standard_user"
    public string Comments  { get; set; }   // "Type the username"
}
```

Nothing unusual here — exactly what you would write in a data-driven
framework. One class, one property per CSV column.

### `CsvStepReader.cs` — the reader

```csharp
public static IEnumerable<KeywordStep> ReadSteps(string filePath)
{
    var lines = File.ReadAllLines(filePath);  // reads every line at once

    return lines
        .Skip(1)                              // discard the header row
        .Where(l => !string.IsNullOrWhiteSpace(l))  // skip blank lines
        .Select(line =>
        {
            var parts = line.Split(',', StringSplitOptions.None);
            // StringSplitOptions.None preserves empty columns (",,")
            // as empty strings — important for optional columns like Value.

            return new KeywordStep
            {
                TestStep = parts[0],
                Action   = parts[1],
                Type     = parts[2],
                Item     = parts[3],
                Value    = parts[4],
                Comments = parts.Length > 5 ? parts[5] : ""
                // Length check: not every row will have a Comments column.
            };
        });
}
```

`IEnumerable<KeywordStep>` — this returns a lazy sequence. Nothing is read
from disk until someone starts iterating the result. In Phase 2 you will
iterate it in a `foreach` loop.

### `Program.cs` — the entry point

```csharp
var steps = CsvStepReader.ReadSteps("TestData/01_First_Test.csv");

Console.WriteLine("=== Test Steps ===");

foreach (var step in steps.OrderBy(s => s.TestStep))
{
    Console.WriteLine(
        $"[{step.TestStep}] {step.Action}_{step.Type} | " +
        $"Item: {step.Item,-20} Value: {step.Value}");
}
```

`s.Item,-20` — the `,20` part is a formatting hint that pads the Item
column to 20 characters, giving the output aligned columns.

## Expected output

```
=== Test Steps ===
[01] NavigateTo_URL | Item: https://www.sauced Value:
[02] Enter_TextBox  | Item: Username            Value: standard_user
[03] Enter_TextBox  | Item: Password            Value: secret_sauce
[04] Click_Button   | Item: LoginButton         Value:
[05] Verify_Visible | Item: ProductsHeading     Value:
```

Notice how `Action_Type` appears as a single combined string. This combined
string — `Enter_TextBox`, `Click_Button`, `Verify_Visible` — is exactly what
the PRISM framework uses as its keyword key. Every keyword in
`KeywordExecutor.cs` is named this way.

## How this maps to the PRISM framework

Open `Framework/Data/CsvStepReader.cs` in the colleague's framework. You
will see the same three operations: `ReadAllLines`, `Skip(1)`, `Select(...)`.
The only additions are a call to `KeywordValidation.Normalize(parts[3])` and
slightly different column handling — the structure is identical.

---

## Practice Exercises

Complete these before moving to Phase 02.

**Exercise 1 — Extra column**
Add a sixth column called `Expected` to the CSV and `KeywordStep` model.
Update `Program.cs` to print it alongside the other columns. Run it and
confirm the new column appears.

**Exercise 2 — Error handling**
What happens if you delete column 4 (Value) from one row so it only has
4 values after splitting? Add a guard in `CsvStepReader` so that `parts[4]`
doesn't throw — use `parts.Length > 4 ? parts[4] : ""` the same way
`Comments` is handled. Test it with a deliberately malformed row.

**Exercise 3 — Multiple test files**
Add a second CSV file (`TestData/02_Second_Test.csv`) with three completely
different steps. Update `Program.cs` to read both files and print all steps
from both, with a clear heading showing which file each group came from.

**Exercise 4 — Understanding the keyword key**
Print the `keyword key` (Action + "_" + Type) for every step alongside the
step number. What would the key look like for a step with Action=`Set` and
Type=`Dropdown`? Write it out before running the code to check your answer.
