# Phase 04 — Page Object Model with the `[Locator]` Attribute

## What you will build

A `LoginPage` class that maps human-readable element names to Playwright
locators, connected via a `[Locator]` custom attribute. A `SimpleLocatorResolver`
reads those attributes via reflection to turn a name like `"Username"` into
a live Playwright locator.

## Why move selectors out of keywords?

In Phase 03's dictionary, you hard-coded the CSS selector right inside the
keyword:

```csharp
["Click_Button"] = async step => await page.ClickAsync("#login-button");
```

This breaks the fundamental rule of automation frameworks: **selectors belong
in one place**. If `#login-button` changes to `[data-test='login-button']`,
you have to find every keyword that used the old selector and update it.

With a Page Object, the selector lives in exactly one place:

```csharp
[Locator("LoginButton", "The main login submit button", "#login-button")]
public ILocator LoginButton => _page.Locator("#login-button");
```

Now `Click_Button` just receives `"LoginButton"` from the CSV and asks the
resolver to look it up. The selector change is one-line in one file.

## The `[Locator]` attribute

```csharp
[AttributeUsage(AttributeTargets.Property)]   // only valid on properties
public class LocatorAttribute : Attribute
{
    public string Name        { get; }   // "LoginButton" — used for lookup
    public string Description { get; }   // used by HTML doc generator
    public string Selector    { get; }   // "#login-button" — for documentation only

    public LocatorAttribute(string name, string description, string selector)
    {
        Name = name; Description = description; Selector = selector;
    }
}
```

The `Selector` property on the attribute is purely for the HTML documentation
generator — it doesn't affect what Playwright actually uses. The page object
property getter `=> _page.Locator("#login-button")` is what Playwright uses.

## The `LoginPage` page object

```csharp
public class LoginPage
{
    private readonly IPage _page;

    public LoginPage(IPage page) { _page = page; }

    [Locator("Username", "The username input field", "#user-name")]
    public ILocator Username => _page.Locator("#user-name");

    [Locator("Password", "The password input field", "#password")]
    public ILocator Password => _page.Locator("#password");

    [Locator("LoginButton", "The login submit button", "#login-button")]
    public ILocator LoginButton => _page.Locator("#login-button");

    [Locator("ErrorMessage", "The error message shown on bad login", "[data-test='error']")]
    public ILocator ErrorMessage => _page.Locator("[data-test='error']");
}
```

Note: each property uses `=>` (expression-bodied property) instead of `{ get; }`.
This means a new `ILocator` object is returned every time the property is read.
This is the correct Playwright pattern — a locator is a "query description",
not a bound DOM node, so creating it fresh is cheap and correct.

## The `SimpleLocatorResolver`

```csharp
public static ILocator? Resolve(string name, IPage page, object? currentPom = null)
{
    // If a specific page object is active, search it first.
    if (currentPom != null)
    {
        var locator = GetFromInstance(name, currentPom);
        if (locator != null) return locator;
    }

    // Otherwise scan all known page types.
    var pageTypes = new[] { typeof(LoginPage) /* add more types as you add pages */ };

    foreach (var type in pageTypes)
    {
        var instance = Activator.CreateInstance(type, page);  // new LoginPage(page)
        var locator  = GetFromInstance(name, instance!);
        if (locator != null) return locator;
    }

    return null;   // not found
}

private static ILocator? GetFromInstance(string name, object instance)
{
    var prop = instance.GetType()
        .GetProperties()
        .FirstOrDefault(p =>
        {
            var attr = p.GetCustomAttribute<LocatorAttribute>();
            return attr != null &&
                   attr.Name.Equals(name, StringComparison.OrdinalIgnoreCase);
        });

    return prop?.GetValue(instance) as ILocator;
}
```

`Activator.CreateInstance(type, page)` calls the constructor `new LoginPage(page)`
dynamically — it doesn't need to know the type at compile time. This is how
the PRISM `SimpleLocatorResolver` handles multiple page types without a
switch-case.

## How `GetLocator` ties it together

The program now calls `SimpleLocatorResolver.Resolve(step.Item, page)` instead
of any hard-coded selector. Keywords become selector-agnostic:

```csharp
["Enter_TextBox"] = async step =>
{
    var element = SimpleLocatorResolver.Resolve(step.Item, page)
        ?? throw new Exception($"Locator '{step.Item}' not found in any page object");
    await element.FillAsync(step.Value);
}
```

## How this maps to the PRISM framework

- `Framework/Locators/LocatorAttribute.cs` — exactly what you build here
- `Framework/Locators/SimpleLocatorResolver.cs` — the reflection-based lookup
- `Pages/LoginPage.cs` — the same pattern with more locators and a `LoginAsync` method

In PRISM, `SimpleLocatorResolver.Resolve` returns a `LocatorResolutionResult`
object (containing both the locator and the page instance that provided it)
rather than just `ILocator?`. This lets `KeywordExecutor` auto-switch the
current page object when a locator is found on a different page. You will
understand why in Phase 05 when navigation changes the active page.

---

## Practice Exercises

**Exercise 1 — Add a locator**
Add a `ProductsTitle` locator to a new `ProductsPage` class. The selector is
`.title` (the "Products" heading visible after login). Add `ProductsPage` to
the array in `SimpleLocatorResolver`. Then add a step to the CSV that uses
`Verify_Visible` on `ProductsTitle` and confirm the resolver finds it.

**Exercise 2 — Name collision detection**
Add the same locator name `"Username"` to both `LoginPage` and a dummy second
class. Update `SimpleLocatorResolver.Resolve` to throw a helpful exception
if the same name is found in more than one page object (the PRISM framework
does this). What message would help a developer debug the collision?

**Exercise 3 — Missing locator**
Call `SimpleLocatorResolver.Resolve("NonExistentThing", page)`. It returns
`null`. Update `GetLocator` in `Program.cs` to throw an exception with the
message `"Locator 'NonExistentThing' not found in any page object"` when
the resolver returns `null`. This is what the PRISM framework does.

**Exercise 4 — Property name fallback**
The PRISM `SimpleLocatorResolver.GetFromType` also matches by raw property
name (e.g. `"LoginButton"` matches the property `public ILocator LoginButton`)
even if no `[Locator]` attribute is present. Add this fallback to your
resolver: check property name (case-insensitive) when the attribute name
doesn't match.
