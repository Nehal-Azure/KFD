// Phase09-NUnit/Framework/VariableManager.cs
//
// Parallel-safe VariableManager: keyed by NUnit test ID.
// With [Parallelizable(ParallelScope.All)], multiple tests run simultaneously.
// A shared static Dictionary would be corrupted when Test A's Load() clears
// Test B's variables mid-execution. Keying by testId isolates each test.

using System.Collections.Concurrent;

namespace Phase09;

public static class VariableManager
{
    // Outer key  = NUnit test ID (unique per parallel test instance)
    // Inner dict = that test's variables (Key → Value)
    private static readonly ConcurrentDictionary<string, Dictionary<string, string>>
        _store = new();

    /// <summary>
    /// Loads variables from a _Variables.csv file for one test.
    /// Silently skips if the file does not exist.
    /// </summary>
    /// <param name="filePath">Full path to the _Variables.csv file.</param>
    /// <param name="testId">NUnit test ID: TestContext.CurrentContext.Test.ID</param>
    public static void Load(string filePath, string testId)
    {
        var vars = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        if (!File.Exists(filePath))
        {
            Console.WriteLine($"  ℹ️  No variables file found — starting empty.");
        }
        else
        {
            var loaded = 0;
            foreach (var line in File.ReadAllLines(filePath).Skip(1))
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split(',', 2);
                if (parts.Length == 2 && !string.IsNullOrWhiteSpace(parts[0]))
                {
                    vars[parts[0].Trim()] = parts[1].Trim();
                    loaded++;
                }
            }
            Console.WriteLine($"  📂 Loaded {loaded} variable(s) from {Path.GetFileName(filePath)}");
        }

        _store[testId] = vars;
    }

    /// <summary>Stores a runtime-captured value for a specific test.</summary>
    public static void Set(string key, string value, string testId)
    {
        if (_store.TryGetValue(testId, out var vars))
            vars[key] = value;
    }

    /// <summary>
    /// Replaces ${key} tokens in the input string with their stored values.
    /// Returns the input unchanged if no tokens match.
    /// </summary>
    public static string Resolve(string input, string testId)
    {
        if (string.IsNullOrEmpty(input) || !input.Contains("${"))
            return input;

        if (!_store.TryGetValue(testId, out var vars) || vars.Count == 0)
            return input;

        foreach (var kvp in vars)
            input = input.Replace($"${{{kvp.Key}}}", kvp.Value);

        // Warn on unresolved tokens.
        if (input.Contains("${"))
        {
            var unresolved = System.Text.RegularExpressions.Regex
                .Matches(input, @"\$\{[^}]+\}");
            foreach (System.Text.RegularExpressions.Match m in unresolved)
                Console.WriteLine($"  ⚠️  Variable '{m.Value}' not defined.");
        }

        return input;
    }

    /// <summary>Removes the variable store for a completed test (memory housekeeping).</summary>
    public static void Cleanup(string testId) => _store.TryRemove(testId, out _);
}
