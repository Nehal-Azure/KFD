namespace Phase09;

public class KeywordStep
{
    public string TestStep  { get; set; } = string.Empty;
    public string Action    { get; set; } = string.Empty;
    public string Type      { get; set; } = string.Empty;
    public string Item      { get; set; } = string.Empty;
    public string Value     { get; set; } = string.Empty;
    public string Comments  { get; set; } = string.Empty;
    public string KeywordKey => $"{Action}_{Type}";
}
