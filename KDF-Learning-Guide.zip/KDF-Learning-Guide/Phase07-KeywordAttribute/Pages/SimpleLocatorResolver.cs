// FILE: Pages/SimpleLocatorResolver.cs
// PURPOSE: Looks up a logical element name (e.g. "LoginButton") across
//          all registered page objects and returns the matching ILocator.
//
// HOW IT WORKS:
//   1. If a "current" page object is provided, search that one first.
//   2. If not found, scan all known page types by instantiating each
//      and checking its [Locator]-decorated properties.
//   3. Return the matching ILocator, or null if nothing matches.
//   4. If the same name exists in multiple page types, throw — that is a
//      data-modelling error that must be fixed, not silently worked around.
//
// WHY REFLECTION?
//   Reflection lets the resolver find locators without needing a switch/case
//   or a manual registry. Add a new page class, add it to the _pageTypes array,
//   and all its locators become instantly discoverable. The PRISM framework
//   goes one step further and uses assembly scanning to remove even the array.

namespace Phase07;

using System.Reflection;
using Microsoft.Playwright;

public static class SimpleLocatorResolver
{
    // Every page object class you want the resolver to scan must be listed here.
    // In Phase 09 / PRISM, this is replaced by assembly scanning:
    //   Assembly.GetAssembly(typeof(LoginPage), typeof(ProductsPage), typeof(ProductsPage)).GetTypes()
    //       .Where(t => t.Namespace?.Contains("Pages") == true)
    // For now, an explicit list is clearer.
    private static readonly Type[] _pageTypes = new[]
    {
        typeof(LoginPage), typeof(ProductsPage), typeof(ProductsPage)
        // Add ProductsPage, CartPage etc. here as you create them.
    };

    /// <summary>
    /// Resolves a logical locator name to a live Playwright ILocator.
    /// </summary>
    /// <param name="name">The logical name from the CSV Item column.</param>
    /// <param name="page">The current Playwright page — passed to page constructors.</param>
    /// <param name="currentPom">
    ///   The currently active page object instance, if one is known.
    ///   Searched first for performance and to prefer the "current" page's locators.
    /// </param>
    /// <returns>
    ///   The matching ILocator, or null if no page object has a property
    ///   with a [Locator] attribute whose Name matches.
    /// </returns>
    public static ILocator? Resolve(string name, IPage page, object? currentPom = null)
    {
        // ── Pass 1: search the current page object ─────────────────────────
        if (currentPom != null)
        {
            var locator = GetFromInstance(name, currentPom);
            if (locator != null)
            {
                Console.WriteLine($"  🔎 Locator '{name}' found in {currentPom.GetType().Name} (current POM)");
                return locator;
            }
        }

        // ── Pass 2: scan all registered page types ─────────────────────────
        var matches = new List<(string pageName, ILocator locator)>();

        foreach (var type in _pageTypes)
        {
            // Skip the current POM — we already checked it in Pass 1.
            if (currentPom != null && type == currentPom.GetType()) continue;

            // Create an instance of the page object using its (IPage) constructor.
            // Activator.CreateInstance is the reflection equivalent of `new T(page)`.
            var instance = Activator.CreateInstance(type, page);
            if (instance == null) continue;

            var locator = GetFromInstance(name, instance);
            if (locator != null)
            {
                matches.Add((type.Name, locator));
            }
        }

        // ── Multiple matches = authoring error ─────────────────────────────
        if (matches.Count > 1)
        {
            var pages = string.Join(", ", matches.Select(m => m.pageName));
            throw new Exception(
                $"Locator '{name}' was found in MULTIPLE page objects: {pages}. " +
                "Locator names must be unique across the whole framework. " +
                "Rename one of them.");
        }

        if (matches.Count == 1)
        {
            Console.WriteLine($"  🔎 Locator '{name}' found in {matches[0].pageName}");
            return matches[0].locator;
        }

        // ── Not found ──────────────────────────────────────────────────────
        return null;
    }

    /// <summary>
    /// Searches one page object instance for a property whose [Locator].Name
    /// matches the given name (case-insensitive).
    /// Also matches by raw property name as a fallback (no attribute needed).
    /// </summary>
    private static ILocator? GetFromInstance(string name, object instance)
    {
        var prop = instance.GetType()
            .GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .FirstOrDefault(p =>
            {
                // Primary match: [Locator] attribute name
                var attr = p.GetCustomAttribute<LocatorAttribute>();
                if (attr != null && attr.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return true;

                // Fallback: raw property name (e.g. "LoginButton" without attribute)
                return p.Name.Equals(name, StringComparison.OrdinalIgnoreCase);
            });

        // GetValue calls the property getter — equivalent to instance.SomeProperty
        return prop?.GetValue(instance) as ILocator;
    }
}
