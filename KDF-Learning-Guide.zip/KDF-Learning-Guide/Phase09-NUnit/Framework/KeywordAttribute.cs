namespace Phase09;
[AttributeUsage(AttributeTargets.Method)]
public class KeywordAttribute : Attribute
{
    public string Name { get; }
    public string Description { get; }
    public KeywordAttribute(string name, string description = "")
    { Name = name; Description = description; }
}
