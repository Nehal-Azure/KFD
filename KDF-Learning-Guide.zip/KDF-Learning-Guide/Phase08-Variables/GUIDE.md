# Phase 08 — Test Variables

## What you will build

A `VariableManager` that lets test steps store a value captured from the
browser and use it in a later step — for example, capture a generated order
number and verify it appears on the confirmation screen, all from CSV with
no code changes.

## The problem variables solve

Some tests need to capture a **dynamic value** that you cannot know at
authoring time (an order number, a generated ID, today's date, a value that
changes with each run). Until now every `Value` column in a CSV was a
hard-coded string. Variables make that cell dynamic:

```
TestStep,Action,Type,Item,Value
07,Capture,Value,CartItemCount,cartCount   ← capture element text, store as "cartCount"
08,Verify,Text,CartBadge,${cartCount}      ← ${cartCount} replaced with stored value
```

The `${cartCount}` token is resolved by `VariableManager.Resolve()` before
the keyword receives the value.

## Two variable sources

### Source 1 — CSV variables file (loaded at test start)

A companion CSV file named `<TestCaseName>_Variables.csv` lives in the same
folder as the steps file. It holds environment-specific or test-specific
constants that you want editable from CSV without touching C# code:

```
Key,Value
BaseUsername,standard_user
ProductName,Sauce Labs Backpack
```

These load at the start of the test and are resolved wherever `${Key}` appears.

### Source 2 — `Capture_Value` keyword (captured during the test)

The `Capture_Value` keyword reads an element's text at runtime and stores it:

```csharp
[Keyword("Capture_Value",
    "Reads the text of the element named Item and stores it under the name in Value.")]
public async Task CaptureValue(KeywordStep step)
{
    var element = GetLocator(step.Item);
    var text    = await element.InnerTextAsync();
    VariableManager.Set(step.Value, text);
    Console.WriteLine($"  📌 Captured '{step.Item}' = '{text}' → stored as ${{{step.Value}}}");
}
```

## `VariableManager` design

```csharp
public static class VariableManager
{
    private static Dictionary<string, string> _variables = new(StringComparer.OrdinalIgnoreCase);

    // Load from a _Variables.csv file at test start.
    // If the file doesn't exist, silently skip (variables are optional).
    public static void Load(string filePath)
    {
        _variables.Clear();
        if (!File.Exists(filePath)) return;

        foreach (var line in File.ReadAllLines(filePath).Skip(1))
        {
            var parts = line.Split(',', 2);    // Split(,, 2) = max 2 parts (key and rest)
            if (parts.Length == 2)
                _variables[parts[0].Trim()] = parts[1].Trim();
        }
    }

    // Store a value captured at runtime (by Capture_Value keyword).
    public static void Set(string key, string value) =>
        _variables[key] = value;

    // Replace all ${key} tokens in a string with their stored values.
    // Called on every step's Item and Value before the keyword runs.
    public static string Resolve(string input)
    {
        if (string.IsNullOrEmpty(input) || !input.Contains("${"))
            return input;   // fast-path: no tokens present

        foreach (var kvp in _variables)
            input = input.Replace($"${{{kvp.Key}}}", kvp.Value);

        return input;
    }
}
```

`Split(',', 2)` — the second argument limits the result to 2 parts, so a
value containing a comma (e.g. `"Sauce Labs Backpack, Black"`) is not split.

## Resolving variables before every keyword runs

Add variable resolution in `Execute()` before `InvokeKeyword()`:

```csharp
public async Task Execute(KeywordStep step)
{
    // Resolve ${token} in both Item and Value before the keyword sees them.
    // This way every keyword is automatically variable-aware without knowing
    // anything about the VariableManager.
    step.Item  = VariableManager.Resolve(step.Item);
    step.Value = VariableManager.Resolve(step.Value);

    var key = $"{step.Action}_{step.Type}";
    await InvokeKeyword(key, step);
}
```

## Parallel running consideration

`VariableManager` uses a `static Dictionary<string, string>`. With parallel
tests (Phase 09) this shared state means Test A's `Load()` call can wipe
Test B's variables mid-execution — a race condition.

The fix used in the PRISM framework (and in the Allure integration files
from the review) is to key the dictionary by test ID:

```csharp
private static readonly ConcurrentDictionary<string, Dictionary<string, string>>
    _store = new();

public static void Load(string filePath, string testId) { ... }
public static string Resolve(string input, string testId) { ... }
```

For this phase (single-test console app), the simple `static Dictionary` is
fine. Phase 09 shows the fix applied inside NUnit.

## The full variable flow in a test

```
CSV variables file loaded → _variables populated with constants
                                ↓
Step 03: Enter_TextBox, Username, ${BaseUsername}
  Resolve("${BaseUsername}") → "standard_user"
  FillAsync("standard_user") ← keyword never sees the token
                                ↓
Step 07: Capture_Value, CartBadge, cartCount
  InnerTextAsync() → "1"
  VariableManager.Set("cartCount", "1")
                                ↓
Step 08: Verify_Text, CartBadge, ${cartCount}
  Resolve("${cartCount}") → "1"
  Expect(element).ToContainTextAsync("1") ← keyword receives the real value
```

## How this maps to the PRISM framework

| Phase 08 | PRISM |
|---|---|
| `VariableManager.cs` (static class) | `VariableManager.cs` (static class, parallel-safe) |
| `VariableManager.Load(filePath)` | `VariableManager.Load(filePath, testId)` |
| `VariableManager.Resolve(input)` | `VariableManager.Resolve(input, testId)` |
| `Capture_Value` keyword | `Capture_Value` keyword in `KeywordExecutor.cs` |
| Resolution in `Execute()` | `ResolveVariable(step.Item)` called inside each keyword in PRISM (slightly different placement) |
| `_Variables.csv` in same folder | `TestData/<TestName>/<TestName>_Variables.csv` |

---

## Practice Exercises

**Exercise 1 — Use a variable from the file**
Add `BaseUrl` to `01_Login_Variables.csv` with value
`https://www.saucedemo.com`. Change step 01 in the CSV from a hard-coded
URL to `${BaseUrl}`. Run it and confirm it still navigates correctly.
This is how the PRISM framework allows the same test to run against
different environments just by changing the variables file.

**Exercise 2 — Capture and verify**
After login, SauceDemo shows the cart icon. Add these two steps to the CSV:
```
10,Capture,Value,ShoppingCartIcon,cartBadge
11,Verify,Text,ShoppingCartIcon,${cartBadge}
```
The cart icon shows `""` when empty (empty string). Does your
`Capture_Value` handle an empty text correctly? What does
`VariableManager.Resolve("${cartBadge}")` return when `cartBadge = ""`?

**Exercise 3 — Missing variable warning**
What happens if a step uses `${NonExistent}` and that key was never loaded
or captured? Currently `Resolve` returns the input unchanged — the keyword
receives the literal string `${NonExistent}`, which will likely cause a
test failure with a confusing message. Change `Resolve` to log a warning
when a `${key}` token is found but has no stored value:
```
⚠️  Variable '${NonExistent}' is not defined. Using literal value.
```

**Exercise 4 — Capture the page title**
Add a keyword `Capture_Title` that calls `await _currentPage.TitleAsync()`
and stores the result using `VariableManager.Set`. Then add a `Verify_Text`
step that checks a heading element against `${pageTitle}`. This is the same
pattern as `Capture_Value` but for the page title rather than an element.
