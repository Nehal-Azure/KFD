// Phase10-Allure/TestBase.cs
//
// Final version. Adds to Phase09 TestBase:
//   [AllureNUnit]        — activates Allure result writing for this class + subclasses
//   Video recording      — RecordVideoDir on context creation
//   Tracing             — Tracing.StartAsync after context ready
//   Artifact TearDown   — screenshot + trace + video attached to Allure on failure

using Allure.Net.Commons;
using Allure.NUnit;
using Microsoft.Playwright;
using NUnit.Framework;
using NUnit.Framework.Interfaces;

namespace Phase10;

[AllureNUnit]    // ← THE CRITICAL ATTRIBUTE. Without this, allure-results/ stays empty.
public class TestBase
{
    // ── Playwright objects ─────────────────────────────────────────────────
    protected static IPlaywright Playwright { get; private set; } = null!;
    protected IBrowser        Browser  { get; private set; } = null!;
    protected IBrowserContext Context  { get; private set; } = null!;
    protected IPage           Page     { get; private set; } = null!;

    // ── Settings ───────────────────────────────────────────────────────────
    protected string BrowserType       { get; private set; } = "chromium";
    protected bool   Headless          { get; private set; } = true;
    protected float  DefaultTimeout    { get; private set; } = 30_000;
    protected float  NavigationTimeout { get; private set; } = 60_000;

    // ── Artifact settings (from .runsettings) ─────────────────────────────
    private string TraceMode =>
        TestContext.Parameters["TraceMode"] ?? "OnFailure";   // Off | OnFailure | Always

    private bool CaptureAllVideos =>
        bool.TryParse(TestContext.Parameters["CaptureAllVideos"], out var v) && v;

    // ── Artifact paths ─────────────────────────────────────────────────────
    private static readonly string ArtifactsRoot =
        Path.Combine(AppContext.BaseDirectory, "test-artifacts");

    private string _videoDir = string.Empty;

    // ──────────────────────────────────────────────────────────────────────
    [OneTimeSetUp]
    public static async Task GlobalSetup()
    {
        Playwright = await Microsoft.Playwright.Playwright.CreateAsync();
        Console.WriteLine("✅ Playwright initialized");
    }

    // ──────────────────────────────────────────────────────────────────────
    [SetUp]
    public async Task Setup()
    {
        Console.WriteLine($"\n🧪 START: {TestContext.CurrentContext.Test.Name} | " +
                          $"Thread: {Environment.CurrentManagedThreadId} | {DateTime.Now:HH:mm:ss}");

        BrowserType       = TestContext.Parameters["Browser"]           ?? "chromium";
        Headless          = bool.TryParse(TestContext.Parameters["Headless"], out var h) ? h : true;
        DefaultTimeout    = float.TryParse(TestContext.Parameters["DefaultTimeout"],    out var dt) ? dt : 30_000;
        NavigationTimeout = float.TryParse(TestContext.Parameters["NavigationTimeout"], out var nt) ? nt : 60_000;

        Browser = BrowserType.ToLower() switch
        {
            "firefox" => await Playwright.Firefox.LaunchAsync(new() { Headless = Headless }),
            "webkit"  => await Playwright.Webkit.LaunchAsync(new() { Headless = Headless }),
            _         => await Playwright.Chromium.LaunchAsync(new() { Headless = Headless })
        };

        // ── Per-test video folder ──────────────────────────────────────────
        // Each test gets its own folder so parallel tests never write the
        // same .webm filename and overwrite each other.
        _videoDir = Path.Combine(ArtifactsRoot, "videos",
            Sanitize(TestContext.CurrentContext.Test.Name));
        Directory.CreateDirectory(_videoDir);

        // ── Create context WITH video recording ────────────────────────────
        Context = await Browser.NewContextAsync(new BrowserNewContextOptions
        {
            ViewportSize    = null,
            RecordVideoDir  = _videoDir,
            RecordVideoSize = new RecordVideoSize { Width = 1280, Height = 720 }
        });

        Page = await Context.NewPageAsync();
        Page.SetDefaultTimeout(DefaultTimeout);
        Page.SetDefaultNavigationTimeout(NavigationTimeout);

        // ── Start tracing ──────────────────────────────────────────────────
        // Records every Playwright action, DOM snapshot, and screenshot.
        // Open trace.zip at https://trace.playwright.dev for a full timeline.
        await Context.Tracing.StartAsync(new TracingStartOptions
        {
            Title       = TestContext.CurrentContext.Test.Name,
            Screenshots = true,
            Snapshots   = true,
            Sources     = true
        });
    }

    // ──────────────────────────────────────────────────────────────────────
    [TearDown]
    public async Task TearDown()
    {
        var failed   = TestContext.CurrentContext.Result.Outcome.Status == TestStatus.Failed;
        var safeName = Sanitize(TestContext.CurrentContext.Test.Name);

        Console.WriteLine($"\n🧹 END: {TestContext.CurrentContext.Test.Name} | " +
                          $"Failed: {failed} | Thread: {Environment.CurrentManagedThreadId}");

        // ── 1. Screenshot on failure ───────────────────────────────────────
        if (failed && Page != null)
        {
            try
            {
                var bytes = await Page.ScreenshotAsync(
                    new PageScreenshotOptions { FullPage = true });

                // Attaches inline in the Allure report's "Attachments" panel.
                AllureApi.AddAttachment(
                    name:    $"{safeName}-failure-screenshot.png",
                    type:    "image/png",
                    content: bytes);

                Console.WriteLine("📸 Failure screenshot attached to Allure");
            }
            catch (Exception e) { Console.WriteLine($"⚠️ Screenshot failed: {e.Message}"); }
        }

        // ── 2. Stop tracing (always) → save if TraceMode demands it ───────
        bool shouldSaveTrace = TraceMode switch
        {
            "Always" => true,
            "Off"    => false,
            _        => failed   // "OnFailure" (default)
        };

        string? tracePath = null;
        if (shouldSaveTrace)
        {
            var traceDir = Path.Combine(ArtifactsRoot, "traces");
            Directory.CreateDirectory(traceDir);
            tracePath = Path.Combine(traceDir, $"{safeName}.zip");
        }

        // StopAsync MUST run regardless — flushes the recorder buffer.
        if (Context != null)
        {
            await Context.Tracing.StopAsync(new TracingStopOptions { Path = tracePath });

            if (tracePath != null && File.Exists(tracePath))
            {
                AllureApi.AddAttachment(
                    name: $"{safeName}-trace.zip  (open at https://trace.playwright.dev)",
                    type: "application/zip",
                    path: tracePath);

                Console.WriteLine("🔍 Trace attached to Allure");
            }

            // ── 3. Close context — CRITICAL: finalises the .webm file ─────
            // Playwright writes the complete video only when the context closes.
            // This line MUST come before we try to read the video file below.
            await Context.CloseAsync();
        }

        // ── 4. Attach video ────────────────────────────────────────────────
        var videoFile = Directory.Exists(_videoDir)
            ? Directory.GetFiles(_videoDir, "*.webm").FirstOrDefault()
            : null;

        bool shouldKeepVideo = failed || CaptureAllVideos;

        if (videoFile != null)
        {
            if (shouldKeepVideo)
            {
                AllureApi.AddAttachment(
                    name: $"{safeName}-video.webm",
                    type: "video/webm",
                    path: videoFile);

                Console.WriteLine("🎬 Video attached to Allure");
            }
            else
            {
                // Delete the passing-test video to save disk space.
                try { Directory.Delete(_videoDir, recursive: true); }
                catch { /* best effort */ }
            }
        }

        // ── 5. Close browser ───────────────────────────────────────────────
        if (Browser != null) await Browser.CloseAsync();
    }

    // ──────────────────────────────────────────────────────────────────────
    [OneTimeTearDown]
    public static void GlobalTeardown()
    {
        Playwright?.Dispose();
        Console.WriteLine("🧹 Playwright disposed — all tests complete.");
    }

    // ── Helper ─────────────────────────────────────────────────────────────
    protected static string Sanitize(string name) =>
        string.Concat(name.Select(c =>
            char.IsLetterOrDigit(c) || c is '-' or '_' ? c : '_'));
}
