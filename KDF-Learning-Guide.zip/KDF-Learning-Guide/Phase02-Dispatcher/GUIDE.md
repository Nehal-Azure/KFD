# Phase 02 — The Keyword Dispatcher

## What you will build

A dispatcher that reads the CSV from Phase 01, looks up each keyword key
in a dictionary, and **calls a C# function** for it. Still no browser — the
functions just print a message. But the dispatch mechanism is the exact
same mechanism the PRISM framework uses, just with a simpler lookup strategy.

## The new concept: dispatching by name

In a traditional data-driven framework, your test class has hard-coded steps:

```csharp
// Traditional data-driven: steps are IN the code
loginPage.EnterUsername(data["Username"]);
loginPage.EnterPassword(data["Password"]);
loginPage.ClickLogin();
```

In a keyword-driven framework, the steps are **in the CSV**. The C# code only
needs to answer one question: "given this keyword name, which function runs?"

The simplest possible answer is a dictionary:

```csharp
var keywords = new Dictionary<string, Func<KeywordStep, Task>>
{
    ["NavigateTo_URL"]  = step => { Console.WriteLine($"Navigate to {step.Item}"); return Task.CompletedTask; },
    ["Enter_TextBox"]   = step => { Console.WriteLine($"Type '{step.Value}' into {step.Item}"); return Task.CompletedTask; },
    ["Click_Button"]    = step => { Console.WriteLine($"Click {step.Item}"); return Task.CompletedTask; },
    ["Verify_Visible"]  = step => { Console.WriteLine($"Check {step.Item} is visible"); return Task.CompletedTask; },
};
```

Then the "engine" is just:

```csharp
var implementation = keywords[step.KeywordKey];
await implementation(step);
```

That is literally it. The "keyword-driven framework" concept, reduced to
its essence, is one dictionary lookup and one method call.

## Why Func<KeywordStep, Task>?

`Func<KeywordStep, Task>` means: "a method that takes a `KeywordStep` and
returns a `Task`" — in other words, an async method that accepts a step.
Every keyword receives the whole `KeywordStep` so it can read `Item`,
`Value`, or any other column it needs.

`Task.CompletedTask` is how you return "success" from an async method that
has nothing to actually wait for. Real keywords (Phase 03 onwards) will
`return` real `Task`s from Playwright `await` calls.

## The execution loop

```csharp
foreach (var step in steps.OrderBy(s => s.TestStep))
{
    Console.WriteLine($"\n── Step {step.TestStep}: {step.KeywordKey} ──");

    if (!keywords.ContainsKey(step.KeywordKey))
    {
        Console.WriteLine($"❌ UNKNOWN KEYWORD: {step.KeywordKey}");
        break;    // stop the test at the first unrecognised keyword
    }

    await keywords[step.KeywordKey](step);
    Console.WriteLine("✅ Done");
}
```

The `break` is important: in a real framework, an unknown keyword is an
authoring mistake (a typo in the CSV), and you want it to fail immediately
rather than silently skipping steps.

## Limitation of the dictionary approach

The dictionary must be manually updated every time a new keyword is added.
In a large framework with 30+ keywords, this becomes a maintenance problem —
it is easy to forget to register a new keyword, and there is no compile-time
check that you did.

Phase 07 introduces the **`[Keyword]` attribute** + reflection approach that
the PRISM framework actually uses. That approach discovers keywords
automatically so the registry never needs manual maintenance. But before you
can appreciate *why* reflection solves this, you need to feel the friction
of the dictionary approach first.

## How this maps to the PRISM framework

The PRISM `KeywordExecutor.InvokeKeyword()` does the same thing as the
dictionary lookup above, just using reflection instead of a dictionary:

```csharp
// PRISM InvokeKeyword — does exactly what the dictionary does, via reflection:
var method = this.GetType()
    .GetMethods(BindingFlags.Instance | BindingFlags.Public)
    .FirstOrDefault(m =>
    {
        var attr = m.GetCustomAttribute<KeywordAttribute>();
        return attr != null && attr.Name.Equals(key, StringComparison.OrdinalIgnoreCase);
    });

await (Task)method.Invoke(this, new object[] { step });
```

Instead of `keywords[step.KeywordKey](step)` — the dictionary lookup — it
uses `method.Invoke(this, new object[] { step })` — reflection lookup. The
result is identical; the mechanism is different. You will build the
reflection version in Phase 07.

---

## Practice Exercises

**Exercise 1 — Add a keyword**
Add `"Verify_Text"` to the dictionary. Its implementation should print:
`"Check that {step.Item} contains text: '{step.Value}'"`. Run it and confirm
the output appears for step 06 in the CSV.

**Exercise 2 — Handle an unknown keyword**
Remove `"Verify_Visible"` from the dictionary so the engine hits an unknown
keyword. Observe the output. Now change `break` to `continue` and see what
happens. Which behaviour is better for a test framework and why?

**Exercise 3 — Extend the CSV**
Add two more steps to the CSV: a `Set_Dropdown` and a `Pause_Seconds`. Add
them to the dictionary with appropriate console output. Notice that adding a
keyword is two operations: add to CSV (data) AND add to dictionary (code).
In Phase 07, you will see how the `[Keyword]` attribute removes one of those
operations.

**Exercise 4 — Step ordering**
What happens if the CSV rows are in the wrong order (e.g. step 04 comes before
step 02)? Try it. Then add `.OrderBy(s => s.TestStep)` to the step reading and
confirm it fixes the ordering. The PRISM framework always sorts by TestStep for
exactly this reason.
