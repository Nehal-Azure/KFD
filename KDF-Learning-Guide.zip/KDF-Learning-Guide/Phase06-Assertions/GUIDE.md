# Phase 06 — Assertions and Screenshot on Failure

## What you will build

Upgrade `Verify_Visible` to use Playwright's **auto-retrying assertion**,
add `Verify_Text` and `Verify_Enabled`, and introduce a
`ExecuteAssertWithScreenshot` wrapper that automatically captures a screenshot
whenever an assertion fails — so every failure is self-documenting.

## Why Playwright's `Expect` instead of `IsVisibleAsync`

Phase 05's `Verify_Visible` called `IsVisibleAsync()`, which is a
**single-moment check**: it looks at the DOM right now and returns
immediately. If the page is still rendering when the check runs, it fails
even though the element was about to appear. You would need to add explicit
`WaitForSelector` calls before every verify step.

Playwright's `Expect` API is different — it is **auto-retrying**:

```csharp
await Assertions.Expect(element).ToBeVisibleAsync();
```

This checks, retries on failure, waits up to the default timeout (30 seconds
by default), and only throws once the timeout is exhausted. You get free
resilience against timing issues with zero extra waiting code.

### The full set of assertion keywords

```csharp
// Verify_Visible — element must be visible on the page
await Assertions.Expect(element).ToBeVisibleAsync();

// Verify_Hidden — element must NOT be visible (can exist in DOM, just hidden)
await Assertions.Expect(element).ToBeHiddenAsync();

// Verify_Text — element's text content must contain the expected string
// step.Value holds the expected text from the CSV Value column
await Assertions.Expect(element).ToContainTextAsync(step.Value);

// Verify_ExactText — element's text must match exactly
await Assertions.Expect(element).ToHaveTextAsync(step.Value);

// Verify_Enabled — element must not be disabled
await Assertions.Expect(element).ToBeEnabledAsync();
```

## `ExecuteAssertWithScreenshot` — the failure wrapper

This is one of the most important patterns in the PRISM framework. Every
assertion keyword delegates to this helper instead of running directly:

```csharp
private async Task ExecuteAssertWithScreenshot(
    Func<Task> assertAction,
    string stepDescription)
{
    try
    {
        await assertAction();
    }
    catch (Exception)
    {
        // Assertion failed — capture evidence before re-throwing.
        await CaptureFailureScreenshot(stepDescription);
        throw;   // re-throw: the test still fails, but now with a screenshot
    }
}
```

The `throw;` (bare throw, no argument) re-throws the original exception
unchanged — the same message, the same stack trace. The screenshot is added
silently as a side effect.

Usage inside a keyword:

```csharp
["Verify_Visible"] = async step =>
{
    var element = GetLocator(step.Item)
        ?? throw new Exception($"Locator '{step.Item}' not found.");

    await ExecuteAssertWithScreenshot(
        async () => await Assertions.Expect(element).ToBeVisibleAsync(),
        $"Verify_Visible_{step.Item}");
}
```

## `CaptureFailureScreenshot` — the evidence capturer

```csharp
private async Task CaptureFailureScreenshot(string name)
{
    try
    {
        var folder = Path.Combine("Screenshots", "Failures");
        Directory.CreateDirectory(folder);

        var timestamp = DateTime.Now.ToString("HHmmss");
        var path = Path.Combine(folder, $"FAIL_{name}_{timestamp}.png");

        await page.ScreenshotAsync(new PageScreenshotOptions
        {
            Path     = path,
            FullPage = true
        });

        Console.WriteLine($"  📸 FAILURE screenshot: {Path.GetFullPath(path)}");
    }
    catch (Exception e)
    {
        // A screenshot failure must NEVER hide the original assertion failure.
        // We swallow this error so the re-throw above still delivers
        // the real failure message to the test runner.
        Console.WriteLine($"  ⚠️  Could not capture screenshot: {e.Message}");
    }
}
```

The inner `try/catch` inside `CaptureFailureScreenshot` is critical — if the
page is in a broken state when the screenshot is attempted (e.g. it crashed),
we cannot let that secondary error mask the real test failure.

## The execution loop with failure handling

The main loop now catches failures and triggers the screenshot pattern:

```csharp
foreach (var step in steps)
{
    try
    {
        await impl(step);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"  ❌ STEP FAILED: {ex.Message}");

        // Take one more screenshot at the step level
        // (in addition to whatever the keyword itself captured)
        await CaptureFailureScreenshot($"Step_{step.TestStep}_{step.KeywordKey}");

        // Stop the test — subsequent steps make no sense after a failure
        passed = false;
        break;
    }
}
```

## Deliberately failing a test — practice verification

The CSV includes a step that is designed to fail:

```
09,Verify,Text,ProductsTitle,WRONG_TEXT,This should FAIL - value doesn't match
```

When step 09 runs, `Expect(element).ToContainTextAsync("WRONG_TEXT")` retries
for 30 seconds, then throws. `ExecuteAssertWithScreenshot` catches it,
captures `FAIL_Verify_Text_ProductsTitle_HHMMSS.png`, and re-throws. The main
loop catches it, captures a second screenshot, and stops.

Open the `Screenshots/Failures/` folder after running — you will see exactly
what the page looked like at the moment of failure. This is the foundation of
self-documenting automated tests.

## How this maps to the PRISM framework

| Phase 06 concept | PRISM equivalent |
|---|---|
| `Assertions.Expect(...).ToBeVisibleAsync()` | Same call in every `Verify_*` method in `KeywordExecutor.cs` |
| `ExecuteAssertWithScreenshot(Func<Task>, string)` | `ExecuteAssertWithScreenshot(Func<Task>, KeywordStep)` in `KeywordExecutor.cs` — same pattern, takes the whole step for richer naming |
| `CaptureFailureScreenshot` | Same method in `KeywordExecutor.cs`, extended in Phase 10 to also call `AllureApi.AddAttachment` |
| Main loop `catch` → screenshot | The `catch` block in `KeywordTests.RunCsvTests` |

---

## Practice Exercises

**Exercise 1 — Verify_Enabled**
Add a `Verify_Enabled` keyword using `Assertions.Expect(element).ToBeEnabledAsync()`.
Add a CSV step that verifies `LoginButton` is enabled before clicking it.
Then test the failure path: add a step that verifies a non-existent element
is enabled and confirm the failure screenshot is generated.

**Exercise 2 — Verify_Text on a real element**
Fix the deliberately-failing step 09 by changing `WRONG_TEXT` to `Products`.
Run it again — step 09 should now pass. Then intentionally break step 06
(change `ProductsTitle` to a typo like `ProductsTitlee`) and observe: which
error message appears? What is in the failure screenshot?

**Exercise 3 — Verify_Hidden**
Add a `Verify_Hidden` keyword using `ToBeHiddenAsync()`. After a successful
login, verify that `ErrorMessage` (the login error banner) is hidden — it
should not be visible when login succeeded. This tests the absence of an
element, which is just as important as testing its presence.

**Exercise 4 — Screenshot naming**
Currently `CaptureFailureScreenshot` uses `HHmmss` for a timestamp. If two
steps fail in the same second (unlikely but possible), they overwrite each
other. Change the timestamp format to `yyyyMMdd_HHmmss_fff` (adding
milliseconds). Also include the test case name in the folder path:
`Screenshots/Failures/<testName>/`. This is what the PRISM framework does
via `_currentTestName`.
