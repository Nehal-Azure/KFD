// Phase09-NUnit/Tests/KeywordTests.cs
//
// The only "test code" in the entire framework.
// RunCsvTests() is short by design — all the real work is done by:
//   • TestBase  — browser lifecycle
//   • KeywordExecutor — keyword dispatch
//   • VariableManager — token resolution
//
// One CSV folder in TestData/ = one NUnit test = one row in the test report.

using NUnit.Framework;

namespace Phase09;

// ── Parallel execution attributes ─────────────────────────────────────────
// ParallelScope.All:        every [Test] case in this fixture may run in parallel.
// InstancePerTestCase:      NUnit creates a fresh KeywordTests object per test,
//                           so instance fields on TestBase never collide between
//                           parallel tests. Required when using ParallelScope.All.
[Parallelizable(ParallelScope.All)]
[FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
[TestFixture]
public class KeywordTests : TestBase
{
    // ── Test case discovery ────────────────────────────────────────────────
    // Called by NUnit at discovery time (before any test runs).
    // Returns one TestCaseData entry per subfolder found in TestData/.
    //
    // TestData/
    //   01_Login_And_Verify/    ← one test case
    //   02_Add_To_Cart/         ← one test case
    //
    // The folder name is the test case's display name everywhere:
    //   • VS Test Explorer
    //   • dotnet test console output
    //   • Allure report (Phase 10)
    public static IEnumerable<TestCaseData> GetTestCases()
    {
        // WorkDirectory is where dotnet test is invoked from — typically the
        // project root. The TestData folder must sit there, or be copied there
        // via <CopyToOutputDirectory> in the .csproj.
        var root = Path.Combine(TestContext.CurrentContext.WorkDirectory, "TestData");

        if (!Directory.Exists(root))
            throw new DirectoryNotFoundException(
                $"TestData folder not found at: {root}\n" +
                "Make sure TestData is set to CopyToOutputDirectory in the .csproj.");

        return Directory
            .GetDirectories(root)
            .OrderBy(d => d)               // consistent ordering across OS
            .Select(dir => new TestCaseData(Path.GetFileName(dir))
                .SetName(Path.GetFileName(dir)));
    }

    // ── Main test method ───────────────────────────────────────────────────
    // NUnit calls this once per entry from GetTestCases(), passing the folder
    // name as testCaseName. The Page property (from TestBase.[SetUp]) is
    // already open and ready to use.
    [Test]
    [TestCaseSource(nameof(GetTestCases))]
    public async Task RunCsvTests(string testCaseName)
    {
        Console.WriteLine($"🚀 Running: {testCaseName} | Thread: {Environment.CurrentManagedThreadId}");

        // ── Locate files ────────────────────────────────────────────────
        var basePath      = Path.Combine("TestData", testCaseName);
        var stepsFile     = Directory.GetFiles(basePath, "*.csv")
                                .FirstOrDefault(f => !Path.GetFileName(f).Contains("Variables"));
        var variablesFile = Path.Combine(basePath, $"{testCaseName}_Variables.csv");

        if (stepsFile == null)
            throw new FileNotFoundException(
                $"No steps CSV found in: {basePath}\n" +
                "Expected a .csv file whose name does NOT contain 'Variables'.");

        // ── Load variables (before reading steps so ${tokens} are ready) ──
        // testId makes the store unique per parallel test — see VariableManager.
        VariableManager.Load(variablesFile, TestContext.CurrentContext.Test.ID);

        // ── Read and sort steps ─────────────────────────────────────────
        var steps = CsvStepReader.ReadSteps(stepsFile)
            .OrderBy(s => s.TestStep)
            .ToList();

        Console.WriteLine($"📄 {steps.Count} steps from {Path.GetFileName(stepsFile)}");

        // ── Execute ─────────────────────────────────────────────────────
        // Page comes from TestBase.Setup() — fresh, isolated, already configured.
        // testCaseName is used for screenshot folder naming inside the executor.
        var executor = new KeywordExecutor(Page, testCaseName);

        foreach (var step in steps)
        {
            Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}" +
                              $"  Item: {step.Item}  Value: {step.Value}");
            await executor.Execute(step);
        }

        // ── Cleanup ─────────────────────────────────────────────────────
        // Remove this test's variable store — good housekeeping on long runs.
        VariableManager.Cleanup(TestContext.CurrentContext.Test.ID);
    }
}
