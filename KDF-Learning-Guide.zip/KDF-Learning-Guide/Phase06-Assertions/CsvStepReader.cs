namespace Phase06;

public static class CsvStepReader
{
    public static IEnumerable<KeywordStep> ReadSteps(string filePath)
    {
        return File.ReadAllLines(filePath)
            .Skip(1)
            .Where(l => !string.IsNullOrWhiteSpace(l))
            .Select(line =>
            {
                var parts = line.Split(',', StringSplitOptions.None);
                return new KeywordStep
                {
                    TestStep = parts[0],
                    Action   = parts[1],
                    Type     = parts[2],
                    Item     = parts[3],
                    Value    = parts.Length > 4 ? parts[4] : string.Empty,
                    Comments = parts.Length > 5 ? parts[5] : string.Empty
                };
            });
    }
}
