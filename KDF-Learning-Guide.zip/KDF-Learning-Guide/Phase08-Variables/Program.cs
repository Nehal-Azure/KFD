// Phase 08 — Test Variables
//
// Run with: dotnet run
//
// What's new vs Phase 07:
//   - VariableManager loads a _Variables.csv file before the test runs
//   - Capture_Value keyword stores runtime-captured element text
//   - Execute() resolves ${token} in Item and Value before every keyword runs
//   - Program.cs calls VariableManager.Load() before the execution loop

using Microsoft.Playwright;
using Phase08;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 08 — Test Variables                        ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── Playwright lifecycle ────────────────────────────────────────────
using var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new() { Headless = false, SlowMo = 300 });
var context = await browser.NewContextAsync();
var page    = await context.NewPageAsync();
page.SetDefaultTimeout(15_000);

// ── Find the test files ────────────────────────────────────────────
var testFolder    = Path.Combine("TestData", "01_Login_Variables");
var stepsFile     = Path.Combine(testFolder, "01_Login_Variables.csv");
var variablesFile = Path.Combine(testFolder, "01_Login_Variables_Variables.csv");

if (!File.Exists(stepsFile))
{
    Console.WriteLine($"❌ Steps file not found: {stepsFile}");
    return;
}

// ── Load variables BEFORE reading steps ───────────────────────────
Console.WriteLine("📂 Loading variables...");
VariableManager.Load(variablesFile);
Console.WriteLine("Current variables:");
VariableManager.PrintAll();
Console.WriteLine();

// ── Read steps ────────────────────────────────────────────────────
var steps = CsvStepReader.ReadSteps(stepsFile).OrderBy(s => s.TestStep).ToList();
Console.WriteLine($"📄 Loaded {steps.Count} steps\n═══ Running ═══\n");

// ── Execute ───────────────────────────────────────────────────────
var executor = new KeywordExecutor(page, "LoginVariablesTest");
var passed   = true;

foreach (var step in steps)
{
    Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}");
    try   { await executor.Execute(step); }
    catch (Exception ex)
    {
        Console.WriteLine($"  ❌ FAILED: {ex.Message.Split('\n')[0]}");
        passed = false;
        break;
    }
    Console.WriteLine();
}

// ── Show variable state after test ────────────────────────────────
Console.WriteLine("📋 Final variable state:");
VariableManager.PrintAll();

await context.CloseAsync();
await browser.CloseAsync();

Console.WriteLine(passed ? "\n✅ ALL STEPS COMPLETED" : "\n❌ TEST FAILED");
Console.WriteLine("See GUIDE.md for practice exercises before moving to Phase 09.");
