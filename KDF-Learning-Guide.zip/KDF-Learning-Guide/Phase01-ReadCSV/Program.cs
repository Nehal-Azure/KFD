// Phase 01 — Read a CSV and Print to Console
//
// Run with: dotnet run
// Expected: Each CSV row printed as "keyword key | Item | Value"
//
// The ONLY goal of this phase is to get comfortable with:
//   1. The CSV column layout
//   2. What a "keyword key" (Action_Type) looks like
//   3. How CsvStepReader turns a line of text into a KeywordStep object

using Phase01;

Console.WriteLine("╔════════════════════════════════════════════════════╗");
Console.WriteLine("║   Phase 01 — Read a CSV and Print to Console       ║");
Console.WriteLine("╚════════════════════════════════════════════════════╝");
Console.WriteLine();

// ── Read the steps from the CSV ───────────────────────────────────────────
// Path is relative to the working directory (the project folder when using
// 'dotnet run'). The TestData folder must be in the same folder as the .csproj.
var filePath = Path.Combine("TestData", "01_First_Test.csv");

if (!File.Exists(filePath))
{
    Console.WriteLine($"❌ Cannot find: {filePath}");
    Console.WriteLine("   Make sure you are running from the Phase01 folder.");
    return;
}

var steps = CsvStepReader.ReadSteps(filePath)
    .OrderBy(s => s.TestStep)  // ensure steps run in the right order
    .ToList();

Console.WriteLine($"📄 Read {steps.Count} steps from: {filePath}");
Console.WriteLine();

// ── Print a column header ─────────────────────────────────────────────────
Console.WriteLine(
    $"{"Step",-6} {"Keyword Key",-22} {"Item",-25} {"Value",-20} Comments");
Console.WriteLine(new string('─', 90));

// ── Print each step ───────────────────────────────────────────────────────
foreach (var step in steps)
{
    // KeywordKey is the combined "Action_Type" string.
    // This is the exact string the PRISM framework uses to look up which
    // C# method to call. You will build that lookup in Phase 02.
    Console.WriteLine(
        $"{step.TestStep,-6} " +
        $"{step.KeywordKey,-22} " +
        $"{step.Item,-25} " +
        $"{step.Value,-20} " +
        $"{step.Comments}");
}

Console.WriteLine(new string('─', 90));
Console.WriteLine();

// ── Show what the executor would do with these ────────────────────────────
Console.WriteLine("What the framework would do with each step:");
Console.WriteLine();

foreach (var step in steps)
{
    Console.WriteLine($"  Step {step.TestStep}:");
    Console.WriteLine($"    Look up keyword:  \"{step.KeywordKey}\"");

    if (!string.IsNullOrWhiteSpace(step.Item))
        Console.WriteLine($"    Target element:   \"{step.Item}\"");

    if (!string.IsNullOrWhiteSpace(step.Value))
        Console.WriteLine($"    With value:       \"{step.Value}\"");

    Console.WriteLine();
}

Console.WriteLine("✅ Phase 01 complete. See GUIDE.md for practice exercises.");
