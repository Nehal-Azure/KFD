# Phase 07 — The `[Keyword]` Attribute and Reflection

## What you will build

Replace the manually maintained `Dictionary<string, Func<KeywordStep, Task>>`
with a proper `KeywordExecutor` class whose methods are discovered automatically
via reflection. Adding a new keyword becomes adding one method — nothing else
changes. This is exactly how the PRISM `KeywordExecutor.cs` works.

## Why the dictionary approach breaks at scale

By Phase 06 your dictionary had 5 keywords and was already long. A real
framework like PRISM has 30+ keywords. With a dictionary you have to:

1. Write the keyword method
2. **Remember to add it to the dictionary**
3. Get the string key exactly right
4. Keep both in sync if the name ever changes

If you forget step 2, the keyword silently produces "Unknown keyword" at
runtime. Step 3 is a typo waiting to happen. The `[Keyword]` attribute +
reflection approach removes steps 2, 3, and 4 entirely.

## The `[Keyword]` attribute

```csharp
[AttributeUsage(AttributeTargets.Method)]
public class KeywordAttribute : Attribute
{
    public string Name        { get; }
    public string Description { get; }

    public KeywordAttribute(string name, string description = "")
    {
        Name        = name;
        Description = description;
    }
}
```

Apply it to any method that implements a keyword:

```csharp
[Keyword("Enter_TextBox", "Types Value into the field named by Item")]
public async Task EnterTextBox(KeywordStep step)
{
    // ...
}
```

The method's own C# name (`EnterTextBox`) no longer matters for dispatch —
only `[Keyword].Name` (`"Enter_TextBox"`) matters. This means C# naming
conventions (PascalCase methods) and keyword naming conventions (Verb_Noun)
can coexist without conflict.

## The `KeywordExecutor` class

All keywords move from a dictionary of lambdas into **methods on a class**:

```csharp
public class KeywordExecutor
{
    private IPage    _currentPage;
    private object?  _currentPom;
    private readonly string _testName;

    public KeywordExecutor(IPage page, string testName)
    {
        _currentPage = page;
        _testName    = testName;
    }

    public async Task Execute(KeywordStep step)
    {
        var key = $"{step.Action}_{step.Type}";
        await InvokeKeyword(key, step);
    }
    ...
}
```

## `InvokeKeyword` — the reflection-based dispatcher

```csharp
private async Task InvokeKeyword(string key, KeywordStep step)
{
    // Scan all public instance methods on THIS class for one whose
    // [Keyword].Name matches the keyword key string from the CSV.
    var method = GetType()
        .GetMethods(BindingFlags.Public | BindingFlags.Instance)
        .FirstOrDefault(m =>
        {
            var attr = m.GetCustomAttribute<KeywordAttribute>();
            return attr != null &&
                   attr.Name.Equals(key, StringComparison.OrdinalIgnoreCase);
        });

    if (method == null)
        throw new Exception(
            $"Keyword not implemented: '{key}'. " +
            $"Add a public method with [Keyword(\"{key}\")] to KeywordExecutor.");

    // Invoke the method. It returns a Task because all keyword methods are async.
    var result = method.Invoke(this, new object[] { step });
    if (result is Task task)
        await task;
}
```

### Why `method.Invoke(this, new object[] { step })`?

`method.Invoke(target, args)` calls the method via reflection:
- `this` = the `KeywordExecutor` instance to call it on (it's an instance method)
- `new object[] { step }` = the arguments array

`Invoke` always returns `object?`. We cast to `Task` and `await` it because we
know from the `[Keyword]` convention that every keyword method returns `Task`.

### Performance note

This reflection scan runs on every single step. For a 20-step test that is
20 reflection scans. The PRISM framework accepts this cost for simplicity.
If it became a bottleneck you would build the dictionary once at startup:

```csharp
// One-time cache (build in constructor, not per-step):
private readonly Dictionary<string, MethodInfo> _cache;

_cache = GetType()
    .GetMethods(BindingFlags.Public | BindingFlags.Instance)
    .Where(m => m.GetCustomAttribute<KeywordAttribute>() != null)
    .ToDictionary(
        m => m.GetCustomAttribute<KeywordAttribute>()!.Name,
        m => m,
        StringComparer.OrdinalIgnoreCase);
```

Then `InvokeKeyword` does `_cache[key].Invoke(this, args)` — one dictionary
lookup instead of a full reflection scan.

## Writing keyword methods

Methods must follow this exact signature — `InvokeKeyword` depends on it:

```csharp
// ✅ Correct signature
[Keyword("Click_Button", "Clicks the element named by Item")]
public async Task ClickButton(KeywordStep step)
{
    var element = GetLocator(step.Item)
        ?? throw new Exception($"Locator '{step.Item}' not found.");
    await element.ClickAsync();
}

// ❌ Wrong — no [Keyword] attribute, never discovered
public async Task ClickSomething(KeywordStep step) { ... }

// ❌ Wrong — not async Task, Invoke cast will fail
[Keyword("Click_Button")]
public void ClickButton(KeywordStep step) { ... }

// ❌ Wrong — extra parameter, Invoke will throw ArgumentException
[Keyword("Click_Button")]
public async Task ClickButton(KeywordStep step, IPage page) { ... }
```

## How `Program.cs` simplifies

With the dictionary gone, `Program.cs` just creates a `KeywordExecutor` and
calls `Execute()` per step — no keyword registration anywhere:

```csharp
var executor = new KeywordExecutor(page, "LoginTest");

foreach (var step in steps.OrderBy(s => s.TestStep))
{
    Console.WriteLine($"▶ [{step.TestStep}] {step.KeywordKey}");
    await executor.Execute(step);
}
```

This is **identical** to `KeywordTests.RunCsvTests` in PRISM — the test
class itself has no knowledge of individual keywords at all.

## Connecting to the PRISM framework

Open `Framework/Engine/KeywordExecutor.cs` in the colleague's framework.
You will recognise every piece:

| Phase 07 | PRISM `KeywordExecutor.cs` |
|---|---|
| `[Keyword("Enter_TextBox", "...")]` | `[Keyword("Enter_TextBox", "Fills a text input...")]` |
| `InvokeKeyword(string key, KeywordStep step)` | `InvokeKeyword(string key, KeywordStep step)` |
| `method.Invoke(this, new object[] { step })` | `method.Invoke(this, new object[] { step })` |
| `_currentPage` field | `_currentPage` field |
| `_currentPom` field | `_currentPOM` field |
| `GetLocator(name)` helper | `GetLocator(name)` helper |

The method names are even the same. After this phase, that file will have
no surprises.

---

## Practice Exercises

**Exercise 1 — Add `Verify_Hidden`**
Add a new keyword method:
```csharp
[Keyword("Verify_Hidden", "Asserts the element named by Item is not visible")]
public async Task VerifyHidden(KeywordStep step) { ... }
```
Use `Assertions.Expect(element).ToBeHiddenAsync()` wrapped in
`ExecuteAssertWithScreenshot`. Add a CSV step that uses it on `ErrorMessage`
after a successful login (error banner should be hidden). Run it.

**Exercise 2 — Duplicate keyword detection**
Add a second method with `[Keyword("Enter_TextBox", "")]`. Run the program.
`InvokeKeyword` currently uses `FirstOrDefault` so it silently picks one.
Change it to throw an error if more than one method has the same keyword name.
This is the same guard the PRISM framework has.

**Exercise 3 — List all registered keywords**
Add a static method `PrintRegisteredKeywords()` that scans `KeywordExecutor`
via reflection and prints every `[Keyword].Name` and `.Description` in
alphabetical order. Call it at program startup. This is what
`KeywordHtmlGenerator.cs` in PRISM does (except it writes HTML instead of
printing to console).

**Exercise 4 — Unknown keyword message**
Change the error message for an unknown keyword to list all available keywords:
```
Keyword 'Set_Dropdown' is not implemented.
Available keywords: Click_Button, Enter_TextBox, NavigateTo_URL,
  Verify_Enabled, Verify_Text, Verify_Visible
```
This is the most useful error message possible for a CSV author who has a typo.
