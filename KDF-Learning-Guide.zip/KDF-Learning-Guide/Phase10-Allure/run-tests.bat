@echo off
REM ═══════════════════════════════════════════════════════════════════
REM run-tests.bat  —  Phase 10 self-service runner (Windows)
REM
REM Double-click in File Explorer to run.
REM Handles: restore → build → browsers → tests → Allure report → open.
REM
REM To override settings, open a Command Prompt and run:
REM   set Headless=false&& run-tests.bat
REM   set TraceMode=Always&& run-tests.bat
REM   set TEST_FILTER=Name=01_Login_And_Verify&& run-tests.bat
REM ═══════════════════════════════════════════════════════════════════
setlocal enabledelayedexpansion

if "%Browser%"==""          set Browser=chromium
if "%Headless%"==""         set Headless=true
if "%TraceMode%"==""        set TraceMode=OnFailure
if "%CaptureAllVideos%"=""  set CaptureAllVideos=false
if "%TEST_FILTER%"==""      set TEST_FILTER=

set SCRIPT_DIR=%~dp0

for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul') do set DT=%%I
set TIMESTAMP=%DT:~0,8%-%DT:~8,6%
set REPORT_DIR=%SCRIPT_DIR%reports\%TIMESTAMP%

echo ════════════════════════════════════════════════════════
echo   KDF Phase 10 — Keyword-Driven Test Run with Allure
echo   Browser=%Browser% ^| Headless=%Headless%
echo   TraceMode=%TraceMode% ^| CaptureAllVideos=%CaptureAllVideos%
if not "%TEST_FILTER%"=="" echo   Filter=%TEST_FILTER%
echo ════════════════════════════════════════════════════════
echo.

cd /d "%SCRIPT_DIR%"

echo [1/5] Restoring NuGet packages...
dotnet restore
if errorlevel 1 (
    echo.
    echo ERROR: Restore failed. Is the .NET 8 SDK installed?
    echo   Run: dotnet --version
    goto :error
)

echo.
echo [2/5] Building...
dotnet build -c Release --no-restore
if errorlevel 1 (
    echo ERROR: Build failed — see compiler errors above.
    goto :error
)

echo.
echo [3/5] Installing Playwright browsers ^(skips if already present^)...
where pwsh >nul 2>nul
if %errorlevel%==0 (
    pwsh bin\Release\net8.0\playwright.ps1 install --with-deps %Browser%
) else (
    echo   WARNING: pwsh not found — skipping automatic install.
    echo   First run only:
    echo     dotnet tool install -g Microsoft.Playwright.CLI
    echo     playwright install %Browser%
)

echo.
echo [4/5] Running tests...
set FILTER_ARG=
if not "%TEST_FILTER%"=="" set FILTER_ARG=--filter "%TEST_FILTER%"
dotnet test -c Release --no-build --settings .runsettings %FILTER_ARG%
set TEST_EXIT=%errorlevel%

echo.
echo [5/5] Generating Allure report...
if not exist "%REPORT_DIR%" mkdir "%REPORT_DIR%"
set ALLURE_RESULTS=bin\Release\net8.0\allure-results

where allure >nul 2>nul
if %errorlevel%==0 (
    allure generate "%ALLURE_RESULTS%" -o "%REPORT_DIR%\allure-report" --clean
    echo.
    echo Report generated: %REPORT_DIR%\allure-report
    echo.
    echo Opening report in browser...
    echo ^(A local web server starts — close this window when done viewing^)
    allure open "%REPORT_DIR%\allure-report"
) else (
    echo.
    echo WARNING: Allure CLI not found — report not generated.
    echo   Install once:
    echo     npm install -g allure-commandline
    echo     ^(or: scoop install allure^)
    echo.
    echo   Raw results are at: %ALLURE_RESULTS%
    echo   Run later: allure serve %ALLURE_RESULTS%
)

echo.
echo ════════════════════════════════════════════════════════
if %TEST_EXIT%==0 (
    echo   ALL TESTS PASSED
) else (
    echo   SOME TESTS FAILED
    echo   Open the Allure report for step-by-step details,
    echo   screenshots, trace files, and test videos.
)
echo ════════════════════════════════════════════════════════
echo.
pause
exit /b %TEST_EXIT%

:error
echo.
pause
exit /b 1
