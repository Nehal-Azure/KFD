// ════════════════════════════════════════════════════════════════════
// FILE: LocatorAttribute.cs
// PURPOSE: Custom attribute that decorates page object properties with
//          a logical name (used for CSV lookup) and a description/selector
//          (used by the HTML documentation generator).
// ════════════════════════════════════════════════════════════════════

namespace Phase09;

using System.Reflection;

/// <summary>
/// Attach to a property on a page object class to register it with the
/// SimpleLocatorResolver. The Name is what appears in the CSV Item column.
///
/// Example usage:
///   [Locator("LoginButton", "The main login submit button", "#login-button")]
///   public ILocator LoginButton => _page.Locator("#login-button");
///
/// The Selector parameter is for documentation only — Playwright uses whatever
/// is inside the property getter itself, not this attribute value.
/// </summary>
[AttributeUsage(AttributeTargets.Property)]
public class LocatorAttribute : Attribute
{
    public string Name        { get; }
    public string Description { get; }
    public string Selector    { get; }

    public LocatorAttribute(string name, string description, string selector)
    {
        Name        = name;
        Description = description;
        Selector    = selector;
    }
}
