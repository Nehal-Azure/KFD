// Phase09-NUnit/TestBase.cs
//
// This is the foundation every test class inherits from.
// It owns the entire Playwright lifecycle so individual test methods
// never have to create or close a browser themselves.
//
// Lifecycle order for a parallel run with 2 tests:
//
//  [OneTimeSetUp]   GlobalSetup()          ← runs ONCE (Playwright created)
//  ┌─────────────────────────────────────────────────────┐
//  │  Test A [SetUp]   → RunCsvTests → [TearDown]        │
//  │  Test B [SetUp]   → RunCsvTests → [TearDown]        │  ← parallel
//  └─────────────────────────────────────────────────────┘
//  [OneTimeTearDown] GlobalTeardown()      ← runs ONCE (Playwright disposed)

using Microsoft.Playwright;
using NUnit.Framework;
using NUnit.Framework.Interfaces;

namespace Phase09;

public class TestBase
{
    // ── static = shared across all parallel test instances ─────────────────
    // IPlaywright is thread-safe; creating it once is significantly faster
    // than creating it per test (it launches a browser-controlling process).
    protected static IPlaywright Playwright { get; private set; } = null!;

    // ── instance = each test gets its own, isolated browser state ──────────
    // These MUST be per-instance: sharing a browser context across tests
    // would mean cookies/localStorage from Test A contaminate Test B.
    protected IBrowser        Browser { get; private set; } = null!;
    protected IBrowserContext Context { get; private set; } = null!;
    protected IPage           Page    { get; private set; } = null!;

    // ── Settings — read from .runsettings in [SetUp] ───────────────────────
    protected string BrowserType       { get; private set; } = "chromium";
    protected bool   Headless          { get; private set; } = true;
    protected float  DefaultTimeout    { get; private set; } = 30_000;
    protected float  NavigationTimeout { get; private set; } = 60_000;

    // ──────────────────────────────────────────────────────────────────────
    // [OneTimeSetUp] — runs EXACTLY ONCE before ANY test in this class runs.
    // Use for setup that is expensive and safe to share (IPlaywright is both).
    // ──────────────────────────────────────────────────────────────────────
    [OneTimeSetUp]
    public static async Task GlobalSetup()
    {
        Playwright = await Microsoft.Playwright.Playwright.CreateAsync();
        Console.WriteLine($"✅ Playwright initialized | Thread: {Environment.CurrentManagedThreadId}");
    }

    // ──────────────────────────────────────────────────────────────────────
    // [SetUp] — runs before EVERY individual [Test] method.
    // Creates a fresh, isolated browser for this specific test.
    // ──────────────────────────────────────────────────────────────────────
    [SetUp]
    public async Task Setup()
    {
        Console.WriteLine(
            $"\n🧪 START: {TestContext.CurrentContext.Test.Name} " +
            $"| Thread: {Environment.CurrentManagedThreadId} " +
            $"| {DateTime.Now:HH:mm:ss.fff}");

        // ── Read .runsettings parameters ─────────────────────────────────
        // TestContext.Parameters reads from the <TestRunParameters> block in
        // the .runsettings file. Using the null-coalescing fallback ensures
        // tests run even without a .runsettings file (uses sensible defaults).
        BrowserType = TestContext.Parameters["Browser"] ?? "chromium";

        Headless = bool.TryParse(TestContext.Parameters["Headless"], out var h) ? h : true;

        // float not int — Playwright's timeout API uses float milliseconds.
        DefaultTimeout = float.TryParse(
            TestContext.Parameters["DefaultTimeout"], out var dt) ? dt : 30_000;
        NavigationTimeout = float.TryParse(
            TestContext.Parameters["NavigationTimeout"], out var nt) ? nt : 60_000;

        // ── Launch browser ────────────────────────────────────────────────
        // The switch expression picks the right browser type from the setting.
        Browser = BrowserType.ToLower() switch
        {
            "firefox" => await Playwright.Firefox.LaunchAsync(new() { Headless = Headless }),
            "webkit"  => await Playwright.Webkit.LaunchAsync(new() { Headless = Headless }),
            _         => await Playwright.Chromium.LaunchAsync(new() { Headless = Headless })
        };

        // ── Create context and page ───────────────────────────────────────
        // A BrowserContext is an isolated session (like a private window).
        // A Page is one tab inside that context.
        Context = await Browser.NewContextAsync(new BrowserNewContextOptions
        {
            ViewportSize = null   // use the OS default window size
        });

        Page = await Context.NewPageAsync();

        // Apply timeouts — these propagate to every Playwright call on this page.
        Page.SetDefaultTimeout(DefaultTimeout);
        Page.SetDefaultNavigationTimeout(NavigationTimeout);

        Console.WriteLine($"🌐 Browser ready: {BrowserType} | Headless: {Headless}");
    }

    // ──────────────────────────────────────────────────────────────────────
    // [TearDown] — runs after EVERY [Test] method, EVEN IF it threw.
    // NUnit's guarantee: [TearDown] always executes.
    // This is where cleanup and (in Phase 10) artifact attachment go.
    // ──────────────────────────────────────────────────────────────────────
    [TearDown]
    public async Task TearDown()
    {
        var outcome  = TestContext.CurrentContext.Result.Outcome.Status;
        var testName = TestContext.CurrentContext.Test.Name;

        Console.WriteLine(
            $"\n🧹 END: {testName} | " +
            $"Status: {outcome} | " +
            $"Thread: {Environment.CurrentManagedThreadId} | " +
            $"{DateTime.Now:HH:mm:ss.fff}");

        // Take a screenshot if the test failed — saved to disk here.
        // Phase 10 also attaches this to the Allure report.
        if (outcome == TestStatus.Failed && Page != null)
        {
            try
            {
                var folder = Path.Combine("Screenshots", "Failures",
                    Sanitize(testName));
                Directory.CreateDirectory(folder);
                var path = Path.Combine(folder,
                    $"FAIL_{DateTime.Now:HHmmss_fff}.png");
                await Page.ScreenshotAsync(new() { Path = path, FullPage = true });
                Console.WriteLine($"📸 Failure screenshot: {path}");
            }
            catch (Exception e)
            {
                // Screenshot failures must never hide the real test failure.
                Console.WriteLine($"⚠️ Screenshot failed: {e.Message}");
            }
        }

        // Close context before browser — order matters.
        // Phase 10 closes context explicitly BEFORE reading the video file
        // because Playwright only finalises .webm files on context close.
        if (Context != null) await Context.CloseAsync();
        if (Browser != null) await Browser.CloseAsync();
    }

    // ──────────────────────────────────────────────────────────────────────
    // [OneTimeTearDown] — runs ONCE after ALL tests have finished.
    // ──────────────────────────────────────────────────────────────────────
    [OneTimeTearDown]
    public static void GlobalTeardown()
    {
        Playwright?.Dispose();
        Console.WriteLine("🧹 Playwright disposed — all tests complete.");
    }

    // ── Helper ─────────────────────────────────────────────────────────────
    protected static string Sanitize(string name) =>
        string.Concat(name.Select(c =>
            char.IsLetterOrDigit(c) || c is '-' or '_' ? c : '_'));
}
