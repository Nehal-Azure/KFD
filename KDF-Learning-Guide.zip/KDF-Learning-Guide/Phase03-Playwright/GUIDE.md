# Phase 03 — Real Browser with Playwright

## What you will build

Replace the console-print functions with **real Playwright browser calls**.
Two keywords work with an actual browser: `NavigateTo_URL` and
`Capture_Screenshot`. When you run this phase, a Chromium window opens,
navigates to SauceDemo, takes a screenshot, and closes.

## What is Playwright?

Playwright is a browser automation library — it controls a real (or headless)
browser from your C# code. Every browser action (`GotoAsync`, `ClickAsync`,
`FillAsync`) is async because it must communicate with the browser process.

The Playwright object hierarchy you will use in every phase from here:

```
IPlaywright   ← the Playwright instance (one per run)
    └── IBrowser      ← a browser process (Chromium, Firefox, WebKit)
            └── IBrowserContext  ← an isolated session (like a private window)
                    └── IPage    ← one browser tab
```

For a simple single-test program, you create one of each and hold them in
variables. In Phase 09, `TestBase` manages this lifecycle for you.

## Setting up Playwright

Add this to your `.csproj`:

```xml
<PackageReference Include="Microsoft.Playwright" Version="1.49.0" />
```

After `dotnet restore`, install the browser binaries once:

```bash
pwsh bin/Debug/net8.0/playwright.ps1 install chromium
```

(On Windows without pwsh: `dotnet tool install -g Microsoft.Playwright.CLI`
then `playwright install chromium`)

## The two new keywords

### `NavigateTo_URL`

```csharp
["NavigateTo_URL"] = async step =>
{
    Console.WriteLine($"  🌐 Navigating to: {step.Item}");
    await page.GotoAsync(step.Item);
    Console.WriteLine($"  ✅ Page title: {await page.TitleAsync()}");
}
```

`step.Item` holds the full URL from the CSV (e.g. `https://www.saucedemo.com`).
`GotoAsync` tells the browser to navigate and waits for the page to load
before returning. This is Playwright's **auto-waiting** — you never need
`Thread.Sleep` for navigation.

### `Capture_Screenshot`

```csharp
["Capture_Screenshot"] = async step =>
{
    var folder = "Screenshots";
    Directory.CreateDirectory(folder);
    var path = Path.Combine(folder, $"{step.Item}.png");
    await page.ScreenshotAsync(new() { Path = path, FullPage = true });
    Console.WriteLine($"  📸 Screenshot saved: {path}");
}
```

`FullPage = true` captures the entire scrollable page, not just the visible
viewport. `step.Item` is the filename (without extension) from the CSV.

## The Playwright lifecycle

```csharp
// Create and launch — these are async because they start a process
using var playwright = await Playwright.CreateAsync();
var browser = await playwright.Chromium.LaunchAsync(new() { Headless = false });
var context = await browser.NewContextAsync();
var page    = await context.NewPageAsync();

// ... run keywords ...

// Clean up — must be called in this order
await context.CloseAsync();
await browser.CloseAsync();
playwright.Dispose();
```

`Headless = false` opens a visible window so you can watch what happens.
Change to `true` for CI/unattended runs (no window, faster).

`using var playwright = ...` — the `using` keyword automatically calls
`playwright.Dispose()` when the variable goes out of scope. For `browser`
and `context`, we call Close explicitly because `CloseAsync` needs `await`.

## How this maps to the PRISM framework

The PRISM `TestBase.cs` manages this exact same lifecycle:
- `[OneTimeSetUp]` — creates `IPlaywright` once
- `[SetUp]` — launches `Browser`, creates `Context` and `Page` per test
- `[TearDown]` — closes `Browser`, and (with Allure) closes `Context`
  explicitly to finalise the video file
- `[OneTimeTearDown]` — disposes `IPlaywright`

Everything in Phase 03 maps directly to what you will see in `TestBase.cs`.

---

## Practice Exercises

**Exercise 1 — Headless mode**
Change `Headless = false` to `Headless = true`. Run again. What is different?
When would you use headless and when would you use headed?

**Exercise 2 — Second keyword**
Add `"Click_Button"` to the dictionary so that step 04 (`Click,Button,LoginButton`)
runs a real `page.ClickAsync(...)`. For now, hard-code the selector as
`"#login-button"` — you will replace hard-coded selectors with page objects
in Phase 04. Hint: `await page.ClickAsync("#login-button");`

**Exercise 3 — Multi-screenshot**
Add steps 02 and 03 (Enter Username/Password) to the dictionary using
`page.FillAsync(selector, step.Value)`. Use the hard-coded selectors
`#user-name` and `#password`. Then add a second screenshot step at the
end of the CSV (after step 07) to capture the products page. Run it and
confirm both screenshots appear in the Screenshots folder.

**Exercise 4 — Error observation**
Change the URL in step 01 to `https://doesnotexist.invalid`. Run it. What
exception do you get? This is what a real navigation failure looks like.
Change it back and run again to confirm it works.
