// ══════════════════════════════════════════════════════════════════
// FILE: Framework/VariableManager.cs
// ══════════════════════════════════════════════════════════════════

namespace Phase08;

/// <summary>
/// Manages test-scoped variables — values either pre-loaded from a CSV
/// file or captured at runtime by the Capture_Value keyword.
///
/// Variables are referenced in step Item and Value cells using ${key} syntax.
/// Resolution happens inside KeywordExecutor.Execute() before any keyword runs,
/// so every keyword is automatically variable-aware with no extra code.
///
/// NOTE ON PARALLEL RUNNING: This static Dictionary is safe for single-threaded
/// console apps (Phase 08) but NOT for parallel NUnit tests (Phase 09).
/// Phase 09 and the PRISM framework key the store by test ID using
/// ConcurrentDictionary&lt;string, Dictionary&lt;string,string&gt;&gt; to isolate each test.
/// </summary>
public static class VariableManager
{
    private static Dictionary<string, string> _variables =
        new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Loads variables from a _Variables.csv file.
    /// Expected format: header row "Key,Value" then one key-value pair per row.
    /// If the file does not exist, silently continues with an empty set.
    /// </summary>
    public static void Load(string filePath)
    {
        _variables.Clear();

        if (!File.Exists(filePath))
        {
            Console.WriteLine($"  ℹ️  No variables file at {filePath} — starting empty.");
            return;
        }

        var loaded = 0;
        foreach (var line in File.ReadAllLines(filePath).Skip(1))
        {
            if (string.IsNullOrWhiteSpace(line)) continue;

            // Split with limit 2 so a value containing "," is not broken.
            var parts = line.Split(',', 2);
            if (parts.Length == 2 && !string.IsNullOrWhiteSpace(parts[0]))
            {
                _variables[parts[0].Trim()] = parts[1].Trim();
                loaded++;
            }
        }

        Console.WriteLine($"  📂 Loaded {loaded} variable(s) from {Path.GetFileName(filePath)}");
    }

    /// <summary>
    /// Stores a runtime-captured value. Called by the Capture_Value keyword.
    /// Overwrites any existing value for the same key.
    /// </summary>
    public static void Set(string key, string value)
    {
        _variables[key] = value;
    }

    /// <summary>
    /// Replaces all ${key} tokens in the input string with their stored values.
    /// Returns the input unchanged if it contains no tokens or if a token has
    /// no matching stored value (with a console warning in the latter case).
    /// </summary>
    public static string Resolve(string input)
    {
        if (string.IsNullOrEmpty(input) || !input.Contains("${"))
            return input;   // fast-path: definitely no tokens

        foreach (var kvp in _variables)
            input = input.Replace($"${{{kvp.Key}}}", kvp.Value);

        // Warn if any ${...} tokens remain after resolution — likely a typo.
        if (input.Contains("${"))
        {
            var remaining = System.Text.RegularExpressions.Regex.Matches(input, @"\$\{[^}]+\}");
            foreach (System.Text.RegularExpressions.Match m in remaining)
                Console.WriteLine($"  ⚠️  Variable '{m.Value}' is not defined. Using literal value.");
        }

        return input;
    }

    /// <summary>Diagnostic: lists all currently stored variables.</summary>
    public static void PrintAll()
    {
        if (_variables.Count == 0)
        {
            Console.WriteLine("  (no variables stored)");
            return;
        }
        foreach (var kvp in _variables)
            Console.WriteLine($"  ${{{kvp.Key}}} = \"{kvp.Value}\"");
    }
}

// ══════════════════════════════════════════════════════════════════
// FILE: Framework/KeywordExecutor.cs  (additions for Phase 08)
// This file shows ONLY what changes vs Phase 07. Copy the full
// Phase07 KeywordExecutor and add the items marked ← NEW.
// ══════════════════════════════════════════════════════════════════

// In the Execute() method — resolve variables BEFORE InvokeKeyword:
//
//   public async Task Execute(KeywordStep step)
//   {
//       step.Item  = VariableManager.Resolve(step.Item);    // ← NEW
//       step.Value = VariableManager.Resolve(step.Value);   // ← NEW
//       var key = $"{step.Action}_{step.Type}";
//       await InvokeKeyword(key, step);
//   }
//
// Add this new keyword method to KeywordExecutor:

public partial class KeywordExecutor   // note: partial is only for splitting this example file
{
    [KeywordAttribute("Capture_Value",
        "Reads the text of the element named by Item and stores it under the key named by Value.")]
    public async Task CaptureValue(KeywordStep step)
    {
        if (string.IsNullOrWhiteSpace(step.Item))
            throw new ArgumentException("Capture_Value requires an Item (element name).");
        if (string.IsNullOrWhiteSpace(step.Value))
            throw new ArgumentException("Capture_Value requires a Value (variable name to store under).");

        var element = GetLocator_Public(step.Item);   // using a public wrapper for partial class

        // Try inner text first; fall back to input value attribute.
        var text = await element.InnerTextAsync();
        if (string.IsNullOrEmpty(text))
            text = await element.InputValueAsync();

        VariableManager.Set(step.Value, text ?? string.Empty);
        Console.WriteLine($"  📌 Captured '{step.Item}' = \"{text}\" → stored as ${{{step.Value}}}");
    }

    // Expose GetLocator for the partial class (in Phase08 full file this is private)
    private ILocator GetLocator_Public(string name) => GetLocator(name);
}
